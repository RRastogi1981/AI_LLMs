import requests

def testSqltoJson():
    sql = """Select count(MB.MEME_FIRST_NAME),*
    from SUBSCRIBER as SB
    inner join MEMBER as MB On SB.SBSB_CK =MB.SBSB_CK
    where MB.MEME_ID_NAME = 'X' and SB.SBSB_ID='Y'"""
    sqlToJsonUrl = "http://127.0.0.1:5000/api/sqlToJson"
    response = requests.get(url = sqlToJsonUrl,params ={'sqlQuery': sql})
    return response.json()

def testJsonToSql(fieldList:str):
    # fieldList:dict = {"1":[{"originalSql": "Select sum(T1.Field1),count(T2.Field2) as CTF\nfrom Table1 as T1\ninner join Table2 as T2 On T1.Field1 =T2.Field5\nwhere T1.Field2 = 'X' and T2.Field3='Y'"}, {"column_name": "Field1", "table_name": {"T1": "Table1"}, "Selected": True, "Used_in_filter": False, "Used_in_join": True, "Summarized": "sum"}, {"column_name": "Field2", "table_name": {"T2": "Table2"}, "Selected": True, "Used_in_filter": False, "Used_in_join": False, "Summarized": "count"}, {"column_name": "Field5", "table_name": {"T2": "Table2"}, "Selected": False, "Used_in_filter": False, "Used_in_join": True, "Summarized": "None"}, {"column_name": "Field2", "table_name": {"T1": "Table1"}, "Selected": False, "Used_in_filter": True, "Used_in_join": False, "Summarized": "None"}, {"column_name": "Field3", "table_name": {"T2": "Table2"}, "Selected": False, "Used_in_filter": True, "Used_in_join": False, "Summarized": "None"}]}
    # fieldList:list = [{"originalSql": "Select sum(T1.Field1),count(T2.Field2) as CTF\nfrom Table1 as T1\ninner join Table2 as T2 On T1.Field1 =T2.Field5\nwhere T1.Field2 = 'X' and T2.Field3='Y'"}, {"column_name": "Field1", "table_name": {"T1": "Table1"}, "Selected": True, "Used_in_filter": False, "Used_in_join": True, "Summarized": "sum"}, {"column_name": "Field2", "table_name": {"T2": "Table2"}, "Selected": True, "Used_in_filter": False, "Used_in_join": False, "Summarized": "count"}, {"column_name": "Field5", "table_name": {"T2": "Table2"}, "Selected": False, "Used_in_filter": False, "Used_in_join": True, "Summarized": "None"}, {"column_name": "Field2", "table_name": {"T1": "Table1"}, "Selected": False, "Used_in_filter": True, "Used_in_join": False, "Summarized": "None"}, {"column_name": "Field3", "table_name": {"T2": "Table2"}, "Selected": False, "Used_in_filter": True, "Used_in_join": False, "Summarized": "None"}]
    # fieldJson = json.dumps(fieldList)
    json_to_sql_Url = "http://127.0.0.1:5000/api/jsonToSql"
    response = requests.get(url = json_to_sql_Url,params ={'fieldDictList1': fieldList})
    return response.json()

response = testSqltoJson()
FieldList:list = response['Fields']
print(FieldList)
response2 = testJsonToSql(str(FieldList))
print(response2)