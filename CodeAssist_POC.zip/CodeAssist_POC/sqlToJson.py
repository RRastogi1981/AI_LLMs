from sql_metadata import Parser
from mo_sql_parsing import parse
import json
from fastapi import FastAPI
from fastapi import Depends, HTTPException, status, APIRouter
import ast
import requests

def getColumnsInTable(tableName: str):
    url = f'http://codeassistapi.azurewebsites.net/api/systems/getfields/table/{tableName}'
    response = requests.get(url = url)
    return response.json()['FieldNames']

def usedInFilter(column,columnDict)->bool:
    if('where' in list(columnDict.keys())):
        if column in columnDict['where']:
            return True
        else:
            return False
    else:
        return False

def usedInJoin(column,columnDict)->bool:
    if('join' in list(columnDict.keys())):
        if column in columnDict['join']:
            return True
        else:
            return False
    else:
        return False
    
def usedInSelect(column,columnDict)->bool:
    if column in columnDict['select']:
        return True
    else:
        return False

def usedInSummary(column,columnDict)->bool:
    if(len(columnDict['Summarized'])!=0):
        for item in columnDict['Summarized']:
            for key in item:
                if(column==item[key]):
                    answer = key

                    break
                else:
                    answer = "None"
            else:
                continue
            break
    else:
        answer = "None"
    return answer

def getSummarizedDictList(moDict:dict,tableAliasDict:dict):
    summarizedDictList = []
    summarizedDictList = []
    for item in moDict['select']:
        if(isinstance(moDict['select'],list)):
            if(list(item.keys())[0]=='all_columns'):
                pass    
            elif(isinstance(item['value'],dict)):
                summarizedDictList.append(item['value'])
        else:
            if(item=='all_columns'):
                pass
            elif(isinstance(moDict['select'][item],dict)):
                summarizedDictList.append(moDict['select'][item])
    
    for item in summarizedDictList:
        for table in tableAliasDict:
            for id in item:
                if(item[id].find(table)!=-1):
                    columnName = item[id].replace(table,tableAliasDict[table])
                    item[id]= columnName

    return summarizedDictList

def sqlToJson(sql:str):
    metaDataParser = Parser(sql)
    columnList = metaDataParser.columns
    columnDict = metaDataParser.columns_dict
    tableAliasDict = metaDataParser.tables_aliases
    tables = metaDataParser.tables
    moDict = parse(sql)
    summarizedDictList = getSummarizedDictList(moDict=moDict,tableAliasDict=tableAliasDict)

    columnDict['Summarized'] = summarizedDictList

    fieldDict = {}
    fieldDictList = []
    fieldDictList.append({'originalSql' :sql})
    allColumnList = []
    allColumnList.append({'originalSql' :sql})
    if('*' in columnList):
        if(len(tableAliasDict)==0):
            for table in tables:
                for column in getColumnsInTable(table):
                    fieldDict = {}
                    fieldDict['column_name'] = column
                    fieldDict['table_name'] = table
                    fieldDict['Selected'] = True
                    fieldDict['Used_in_filter']=usedInFilter(column,columnDict)
                    fieldDict['Used_in_join']=usedInJoin(column,columnDict)
                    fieldDict['Summarized'] = usedInSummary(column,columnDict)

                    allColumnList.append(fieldDict)


        else:                   
            for tableAlias in tableAliasDict:
                # for tableName in FieldsInTable:
                #     if(tableAliasDict[tableAlias]==tableName):
                for column in getColumnsInTable(tableAliasDict[tableAlias]):
                    fieldDict = {}
                    fieldDict['column_name'] = column
                    fieldDict['table_name'] = {tableAlias:tableAliasDict[tableAlias]}
                    fieldDict['Selected'] = True                    
                    fieldDict['Used_in_filter']=usedInFilter(column,columnDict)
                    fieldDict['Used_in_join']=usedInJoin(column,columnDict)
                    fieldDict['Summarized'] = usedInSummary(column,columnDict) 

                    allColumnList.append(fieldDict)
    else:
        for column in columnList:
            fieldDict = {}
            if(column.find('.')==-1):
                fieldDict['column_name']=column
                fieldDict['table_name']=tables[0]
            else:
                fieldDict['column_name']=column.split(".")[1]
                fieldDict['table_name'] = column.split(".")[0]
                for tableAlias in tableAliasDict:
                    if(fieldDict['table_name']==tableAliasDict[tableAlias]):
                        fieldDict['table_name']={tableAlias:tableAliasDict[tableAlias]}

            fieldDict['Selected'] = usedInSelect(column,columnDict)
            fieldDict['Used_in_filter'] = usedInFilter(column,columnDict)
            fieldDict['Used_in_join'] = usedInJoin(column,columnDict)
            fieldDict['Summarized'] = usedInSummary(column,columnDict)    

            allColumnList.append(fieldDict)
    
    # return allColumnList
    return {'Status':"Success",'Fields':allColumnList, "status_code": status.HTTP_200_OK}
    # return resultFields

def JsonToSqlSelect(fieldDictList:list):
    selectString = "select "
    i = 0
    for field in fieldDictList[1:]:
        if(field['Selected']):
            if(field['Summarized']!='None'):
                for tableAlias in field['table_name']:
                    selectString = selectString + field['Summarized'] + "(" + tableAlias + "." + field['column_name'] + ")"
            else:
                for tableAlias in field['table_name']:
                    selectString = selectString + tableAlias + "." + field['column_name']
            selectString += ", "
    selectString2 = selectString[:-2]

    return selectString2

def jsonToSql(fieldDictListstr:str):
    fieldDictList = ast.literal_eval(fieldDictListstr)
    # fieldDictList = fieldDict['1']
    # fieldDictList = json.loads(fieldDictList)
    sqlGiven = fieldDictList[0]['originalSql']
    fromindex = sqlGiven.lower().find("from")
    sqlWithoutSelect = sqlGiven[fromindex:]
    sqlSelect = JsonToSqlSelect(fieldDictList=fieldDictList)
    sqlWithSelect = sqlSelect + sqlWithoutSelect
    # return sqlWithSelect
    return {'Status':"Success",'sql':sqlWithSelect, "status_code": status.HTTP_200_OK}

# sql = """Select count(MB.MEME_FIRST_NAME),*
# from SUBSCRIBER as SB
# inner join MEMBER as MB On SB.SBSB_CK =MB.SBSB_CK
# where MB.MEME_ID_NAME = 'X' and SB.SBSB_ID='Y'"""
# fieldDictList1 = sqlToJson(sql=sql)
# print(len(fieldDictList1))
# # # for field in fieldDictList1:
# # #     print(field)
# print(json.dumps(fieldDictList1))
# with open ("trial.json","w") as f:
#     json.dump(fieldDictList1,f)
# sqlOut = jsonToSql(str(fieldDictList1))
# print(sqlOut)