import models as models
from sqlalchemy.orm import Session
from fastapi import Depends, HTTPException, status, APIRouter
from controller import get_db

app = APIRouter()

# @app.get("/api/systems", status_code=status.HTTP_200_OK)
# def get_systems(
#     db: Session = Depends(get_db), limit: int = 10, page: int = 1, search: str = ""
# ):
#     skip = (page - 1) * limit

#     systems = (
#         db.query(models.System)
#         .filter(models.System.domain_name.contains(search))
#         .limit(limit)
#         .offset(skip)
#         .all()
#     )
#     return {"Status": "Success", "Results": len(systems), "systems": systems}

# @app.post("/api/systems", status_code=status.HTTP_201_CREATED)
# def create_system(payload: models.SystemBaseSchema, db: Session = Depends(get_db)):
#     new_system = models.System(**payload.model_dump())
#     db.add(new_system)
#     db.commit()
#     db.refresh(new_system)
#     return {"Status": "Success", "System": new_system, "status_code":status.HTTP_201_CREATED}

# @app.delete("/api/systems/{id}", status_code=status.HTTP_200_OK)
# def delete_system(id: int, db: Session = Depends(get_db)):
#     systems_query = db.query(models.System).filter(models.System.id == id)
#     system = systems_query.first()
#     if not system:
#         raise HTTPException(
#             status_code=status.HTTP_404_NOT_FOUND,
#             detail=f"No system with this id: {id} found",
#         )
#     systems_query.delete(synchronize_session=False)
#     db.commit()
#     return {"Status": "Success", "Message": "id deleted successfully"}

# @app.get("/api/systems/{id}", status_code=status.HTTP_200_OK)
# def get_user(id: int, db: Session = Depends(get_db)):
#     systems_query = db.query(models.System).filter(models.System.id == id)
#     system = systems_query.first()
#     if not system:
#         raise HTTPException(
#             status_code=status.HTTP_404_NOT_FOUND,
#             detail=f"No system with this id: `{id}` found",
#         )
#     return {"Status": "Success", "ID": id, "systems": system}

# @app.patch("/api/systems/{id}", status_code=status.HTTP_202_ACCEPTED)
# def update_system(id: int, payload: models.SystemBaseSchema, db: Session = Depends(get_db)):
#     systems_query = db.query(models.System).filter(models.System.id == id)
#     system = systems_query.first()

#     if not system:
#         raise HTTPException(
#             status_code=status.HTTP_404_NOT_FOUND,
#             detail=f"No System with this id: {id} found",
#         )
#     update_data = payload.model_dump(exclude_unset=True)
#     systems_query.filter(models.System.id == id).update(update_data, synchronize_session=False)
#     db.commit()
#     db.refresh(system)
#     return {"Status": "Success", "system": system}



