from flask import Flask, render_template, request, jsonify
#from flask_restful import Resource, Api, marshal_with, fields
#from flask_sqlalchemy import SQLAlchemy
from connections import *
#from clinical_document import *
from Clinical_Document.controller import *
from Clinical_Document_Summary.controller import *
from Clinical_Evidence_Summary.controller import *
from Patient.controller import *
from Provider.controller import *
#from models_bkp import clinical_document
import json
import os
from datetime import datetime



app = Flask(__name__)


@app.route('/')
def index():
    return "Server Works"

@app.route('/all/<string:id>', methods=['GET'])
def all_cdsid_request(id):
    result = {}    
    response = CD_clinical_document_by_id(id,'GET')
    #print(type(response))
    clinical_doc = [b.serialize() for b in response]
    result['clinical_document'] = clinical_doc
    #print(clinical_doc[0]['Identifier'])
    
    if (len(clinical_doc)==0):
            return  jsonify({
            'status': '200',
            'res': '',
            'msg': 'No Data Present'})
    else:
        identifier = clinical_doc[0]['Identifier']
        response = CDS_clinical_document_by_id(identifier,'GET')
        clinical_doc_summary = [b.serialize() for b in response]
        result['clinical_document_summary'] = clinical_doc_summary     

        response = Pat_clinical_document_by_id(identifier,'GET')
        patient_doc = [b.serialize() for b in response]
        result['patient'] = patient_doc

        response = Pro_clinical_document_by_id(identifier,'GET')
        provider_doc = [b.serialize() for b in response]
        result['provider'] = provider_doc
        return  jsonify({
            'status': '100',
            'res': result,
            'msg': len(clinical_doc)})
    
@app.route('/allcds/<string:id>', methods=['GET'])
def all_cseid_request(id):
    result = {}    
    response = CDS_clinical_document_by_cds_id(id,'GET')
    #print(type(response))
    clinical_doc_summary = [b.serialize() for b in response]
    result['clinical_document_summary'] = clinical_doc_summary
    #print(clinical_doc_summary)
    
    if (len(clinical_doc_summary)==0):
            return  jsonify({
            'status': '200',
            'res': '',
            'msg': 'No Data Present'})
    else:
               
        identifier = clinical_doc_summary[0]['CDS_Identifier']
        response = CES_clinical_document_by_id(identifier,'GET')
        clinical_doc_evi_summary = [b.serialize() for b in response]
        result['clinical_evidence_summary'] = clinical_doc_evi_summary
             
        return  jsonify({
            'status': '100',
            'res': result,
            'msg': len(clinical_doc_summary)})


    
#@app.route('/all/<string:id>',methods=['GET'])

#def all_get_request():
#    response = CD_clinical_document_by_id(id,'GET')
#    clinical_doc = [b.serialize() for b in response]
#    return (print(type(clinical_doc),clinical_doc))
    

# Clinical Document
from Clinical_Document.urls import *
# Clinical Document Summary
from Clinical_Evidence_Summary.urls import *
from Clinical_Document_Summary.urls import *
# Patient
from Patient.urls import *
# Provider
from Provider.urls import *
from GenAI.urls import *



if __name__ == '__main__':
    app.run(debug=True)
    #app.run(host="0.0.0.0",port=5000)