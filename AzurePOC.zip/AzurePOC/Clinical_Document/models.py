class clinical_document:
  def __init__(self, Identifier,Document_Name,Document_Path,
                Document_Review_Status,
                Prior_Auth_Description,            
                Patient_Document_id,
                Provider_Document_id,
                Document_Receive_dts,
                Document_Evaluation_dts,
                Last_Updated_dts, 
                User_Name):
    
    self.Identifier = Identifier
    self.Document_Name = Document_Name
    self.Document_Path = Document_Path
    self.Document_Review_Status = Document_Review_Status
    self.Prior_Auth_Description = Prior_Auth_Description
    self.Patient_Document_id = Patient_Document_id
    self.Provider_Document_id = Provider_Document_id
    self.Document_Receive_dts = Document_Receive_dts
    self.Document_Evaluation_dts = Document_Evaluation_dts
    self.Last_Updated_dts = Last_Updated_dts
    self.User_Name = User_Name


  def __repr__(self):
    return '<id {}>'.format(self.Identifier)

  def serialize(self):

    return {
    'Identifier' : self.Identifier,
    'Document_Name' : self.Document_Name,
    'Document_Path' : self.Document_Path,
    'Document_Review_Status' : self.Document_Review_Status,
    'Prior_Auth_Description' : self.Prior_Auth_Description,
    'Patient_Document_id' : self.Patient_Document_id,
    'Provider_Document_id' : self.Provider_Document_id,
    'Document_Receive_dts' : self.Document_Receive_dts,
    'Document_Evaluation_dts' : self.Document_Evaluation_dts,
    'Last_Updated_dts' : self.Last_Updated_dts,
    'User_Name' : self.User_Name
    }
  
  '''
  def validate_input(self):
    
    if len(self.Identifier) > 50:
      return {
        'field_name' : "Identifier",
        'Validation' : "False"
      }
    if len(self.Document_Name) > 100:
      return {
        'field_name' : "Document_Name",
        'Validation' : "False"
      }
    if len(self.Document_Path) > 150:
      return {
        'field_name' : "Document_Path",
        'Validation' : "False"
      }
    if len(self.Document_Review_Status) > 10:
      return {
        'field_name' : "Document_Review_Status",
        'Validation' : "False"
      }
    if len(self.Document_Name) > 100:
      return {
        'field_name' : "Document_Name",
        'Validation' : "False"
      }
    if len(self.Document_Name) > 100:
      return {
        'field_name' : "Document_Name",
        'Validation' : "False"
      }
    if len(self.Document_Name) > 100:
      return {
        'field_name' : "Document_Name",
        'Validation' : "False"
      }
    if len(self.Document_Name) > 100:
      return {
        'field_name' : "Document_Name",
        'Validation' : "False"
      }
'''