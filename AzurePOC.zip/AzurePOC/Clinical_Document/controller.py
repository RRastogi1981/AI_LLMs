from flask import Flask, render_template, request, jsonify
#from flask_restful import Resource, Api, marshal_with, fields
#from flask_sqlalchemy import SQLAlchemy
from connections import * 
#from . import connections
import json
#import os
from datetime import datetime
import Clinical_Document.models as model

def CD_insert_clinical_data(post_request):
    
    cursor = conn.cursor()
    now = datetime.now()
    #user= os.getlogin()
    formatte_date = now.strftime('%Y-%m-%d %H:%M:%S')
    datas = model.clinical_document(post_request['Identifier'],
                              post_request['Document_Name'],
                              post_request['Document_Path'],
                              post_request['Document_Review_Status'],
                              post_request['Prior_Auth_Description'],
                              post_request['Patient_Document_id'],
                              post_request['Provider_Document_id'],
                              post_request['Document_Receive_dts'],
                              post_request['Document_Evaluation_dts'],
                              formatte_date,
                              post_request['User_Name'])
    try:
        query= """INSERT INTO clinical_document (Identifier,Document_Name,Document_Path,
                Document_Review_Status,
                Prior_Auth_Description,            
                Patient_Document_id,
                Provider_Document_id,
                Document_Receive_dts,
                Document_Evaluation_dts,
                Last_Updated_dts, 
                User_Name)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""" 

        cursor.execute(query,(datas.Identifier,datas.Document_Name,datas.Document_Path,datas.Document_Review_Status,
                              datas.Prior_Auth_Description, datas.Patient_Document_id,datas.Provider_Document_id,
                              datas.Document_Receive_dts, datas.Document_Evaluation_dts,datas.Last_Updated_dts,
                              datas.User_Name))
        conn.commit()
        return datas
        #return [True,'Inserted Sucessfully',datas]    
    except Exception as e:
        text = "Error while inserting data:" + str(e)
        conn.rollback()
        return text    
    cursor.close()

    #return datas


def CD_get_clinical_data():
    datas = []
    try:
        query = "select * from clinical_document"
        cursor = conn.cursor()
        cursor.execute(query)
        data=cursor.fetchall()
        for i in data:

            clinical_doc = model.clinical_document(i[0],i[1], i[2],i[3],i[4],i[5],i[6],i[7],i[8], i[9],i[10])
            datas.append(clinical_doc)  
        #return [True,'Records Returned Sucessfully',datas]
        return datas    
    except Exception as e:
        text = "Error while returning data:" + str(e)
        conn.rollback()
        return text

    return datas


def CD_clinical_document_by_id(id, operation):
    datas = []
    cursor = conn.cursor()

    if operation == 'GET':
        try:
            query = "SELECT * FROM clinical_document where Identifier = %s ;"
            cursor.execute(query,(id,))
            data = cursor.fetchall()
            for i in data:
                clinical_doc = model.clinical_document(i[0],i[1], i[2],i[3],i[4],i[5],i[6],i[7],i[8], i[9],i[10])  
                datas.append(clinical_doc)  

            cursor.close()
            #return [True,'Records Returned Sucessfully',datas]
            return datas    
        except Exception as e:
            text = "Error while returning the data:" + str(e)
            conn.rollback()
            return text    

        #conn.close()
        #return datas

    if operation == 'DELETE':
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM clinical_document WHERE Identifier = %s;", (id,))
            conn.commit()
            return "deleted"
            #return [True,'Records Deleted Sucessfully',id]    
        except Exception as e:
            text = "Error while deleting the data:" + str(e)
            conn.rollback()
            return text    

def CD_clinical_document_put_by_id(id, operation,request_data):

    if operation == 'PUT':
        try:
            cursor = conn.cursor()
            now = datetime.now()
            #user= os.getlogin()
            formatte_date = now.strftime('%Y-%m-%d %H:%M:%S')
            #print(type(request_data),request_data)
            data = model.clinical_document(id,
                                    request_data['Document_Name'],
                                    request_data['Document_Path'],
                                    request_data['Document_Review_Status'],
                                    request_data['Prior_Auth_Description'],
                                    id,
                                    id,
                                    request_data['Document_Evaluation_dts'],
                                    request_data['Document_Evaluation_dts'],
                                    formatte_date,
                                    request_data['User_Name'])
            cursor.execute("UPDATE clinical_document SET Document_Review_Status = %s,Last_Updated_dts =%s,User_Name=%s WHERE Identifier = %s ;",(data.Document_Review_Status, data.Last_Updated_dts,data.User_Name,id))
            conn.commit()
            #conn.close()
            #return "updated"
            #return [True,'Records Updated Sucessfully',data]
            return data    
        except Exception as e:
            text = "Error while updating the data:" + str(e)
            conn.rollback()
            return text    