from flask import Flask, render_template, request, jsonify
#from flask_restful import Resource, Api, marshal_with, fields
#from flask_sqlalchemy import SQLAlchemy
#from connections import *
#from clinical_document import *
from Clinical_Document.controller import *
from app import app


@app.route('/cd', methods=['POST'])
def CD_post_request():
    post_request = request.get_json()
    #print(post_request)
    try:
        response = (CD_clinical_document_by_id(post_request['Identifier'], 'GET'))
    #    print(response)
        clinical_doc = [b.serialize() for b in response]
        if (len(clinical_doc)==0):
            response = CD_insert_clinical_data(post_request)
    #        print(type(response))
    #        if response[0] == True:     
            return  jsonify({
                'status': '100',
                'res': post_request,
                'msg': 'Record Inserted Sucessfully'})
    #        else:
    #            return  jsonify({
    #            'status': '200',
    #            'res': post_request,
    #            'msg': response[1]})     
        else:
                return  jsonify({
                'status': '200',
                'res': post_request,
                'msg': 'ID already existing - Insert failed'})    
   
    except Exception as e:
        #print(e)
        #print("Error while inserting data")
                text = 'DB Error - Insert failed::' + e
                return  jsonify({
                'status': '200',
                'res': post_request,
                'msg': text})


@app.route('/cd',methods=['GET'])
def CD_get_request():

    response = CD_get_clinical_data()
    clinical_doc = [b.serialize() for b in response]
    if (len(clinical_doc)==0):
        return  jsonify({
            'status': '200',
            'res': '',
            'msg': 'No Data Present'})
    else:
        return  jsonify({
            'status': '100',
            'res': clinical_doc,
            'msg': len(clinical_doc)})
    

@app.route('/cd/<string:id>', methods=['GET', 'DELETE', 'PUT'])
def CD_id_request(id):
        
    response = CD_clinical_document_by_id(id,'GET')
    #print(type(response))
    clinical_doc = [b.serialize() for b in response]
    #print(clinical_doc)
    if request.method == 'GET':
        if (len(clinical_doc)==0):
            return  jsonify({
            'status': '200',
            'res': '',
            'msg': 'No Data Present'})
        else:
            return  jsonify({
            'status': '100',
            'res': clinical_doc,
            'msg': len(clinical_doc)})
    
    if request.method == 'DELETE':
        if (len(clinical_doc)==0):
            return  jsonify({
            'status': '200',
            'res': id,
            'msg': 'No Data Present to Delete'})
        else:
            response = CD_clinical_document_by_id(id,str(request.method))
            return  jsonify({
            'status': '100',
            'res': clinical_doc,
            'msg': "Record Deleted Successfully"})
        
    
    if request.method == 'PUT':
        post_request = request.get_json()
        if (len(clinical_doc)==0):
            return  jsonify({
            'status': '200',
            'res': id,
            'msg': 'No Data Present to Update'})
        else:
            response = CD_clinical_document_put_by_id(id,str(request.method),post_request)
            return  jsonify({
            'status': '100',
            'res': post_request,
            'msg': "Record Updated Successfully"})
        
        #return response
