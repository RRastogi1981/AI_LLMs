import mysql.connector
import pathlib
import psycopg2
from functions import read_yaml_file
from functions import get_keyvault_value

def get_ssl_cert():
    current_path = pathlib.Path(__file__).parent
    print("Current Path",current_path)
    print(str(current_path / 'DigiCertGlobalRootG2.crt.pem'))
    return str(current_path / 'DigiCertGlobalRootG2.crt.pem')



def postgre_sql_connect(data):
    env     = data['FLASK_ENV']
    DB_NAME = data[env]['DB_NAME']
    DB_USER = data[env]['DB_USER']
    DB_PASS = get_keyvault_value(keyVaultName = data['KEY_VAULT_NAME'],secret="DBPASSPG")
    DB_HOST = data[env]['DB_HOST']
    DB_PORT = data[env]['DB_PORT']
    try:
        conn = psycopg2.connect(database=DB_NAME,
                                user=DB_USER,
                                password=DB_PASS,
                                host=DB_HOST,
                                port=DB_PORT)
        print("Postgre Database connected successfully")
    except psycopg2.Error as e:
        print("Postgre Database not connected successfully:",e)
    return conn

def mysql_sql_connect(data):
    env     = data['FLASK_ENV']
    DB_NAME = data[env]['DB_NAME']
    DB_USER = data[env]['DB_USER']
    DB_PASS = "User@12345678"
    DB_HOST = data[env]['DB_HOST']
    DB_PORT = data[env]['DB_PORT']
    DB_SSL = data[env]['DB_SSL']
    #DB_NAME_MS = "ccpdb"
    #DB_USER_MS = "demouser"
    #DB_PASS_MS = "User@12345678"
    #DB_HOST_MS = "sqlserverdev.mysql.database.azure.com"
    #DB_PORT_MS = "3306"
    #DB_SSL  = "C:\\Users\\devadmin\\Documents\\AzurePOC\\DigiCertGlobalRootCA.crt.pem"
    try:
        conn = mysql.connector.connect(user=DB_USER,
                                        password=DB_PASS,
                                        host=DB_HOST,
                                        port=DB_PORT,
                                        database=DB_NAME,
                                        ssl_ca= DB_SSL,
                                        ssl_disabled=False,
                                        consume_results=True)
        print("MySQL Database connected successfully")
    except:
        print("MySQL Database not connected successfully")
    
    return conn

data = read_yaml_file()
#env = 'Development'
DB_CONFIG_DATABASE = data['DB_CONFIG_DATABASE']


if DB_CONFIG_DATABASE == 'postgre':
    conn = postgre_sql_connect(data)
if DB_CONFIG_DATABASE == 'mysql':
    conn = mysql_sql_connect(data)

# mysql> describe clinical_document;
# +-------------------------+--------------+------+-----+---------+-------+
# | Field                   | Type         | Null | Key | Default | Extra |
# +-------------------------+--------------+------+-----+---------+-------+
# | Identifier              | varchar(50)  | NO   | PRI | NULL    |       |
# | Document_Name           | varchar(100) | NO   |     | NULL    |       |
# | Document_Path           | varchar(150) | NO   |     | NULL    |       |
# | Document_Review_Status  | varchar(15)  | NO   |     | NULL    |       |
# | Prior_Auth_Description  | varchar(150) | NO   |     | NULL    |       |
# | Patient_Document_id     | varchar(50)  | NO   |     | NULL    |       |
# | Provider_Document_id    | varchar(50)  | NO   |     | NULL    |       |
# | Document_Receive_dts    | timestamp    | YES  |     | NULL    |       |
# | Document_Evaluation_dts | timestamp    | YES  |     | NULL    |       |
# | Last_Updated_dts        | timestamp    | YES  |     | NULL    |       |
# | User_Name               | varchar(10)  | YES  |     | NULL    |       |
# +-------------------------+--------------+------+-----+---------+-------+
    
# mysql> describe clinical_document_summary;
# +-----------------------+---------------+------+-----+---------+-------+
# | Field                 | Type          | Null | Key | Default | Extra |
# +-----------------------+---------------+------+-----+---------+-------+
# | CDS_Identifier        | varchar(50)   | NO   | PRI | NULL    |       |
# | Identifier            | varchar(50)   | NO   |     | NULL    |       |
# | Concept_Name          | varchar(100)  | NO   |     | NULL    |       |
# | Concept_LLM_Summary   | varchar(1000) | YES  |     | NULL    |       |
# | Reference_Text        | varchar(255)  | YES  |     | NULL    |       |
# | Response_Attribute    | varchar(500)  | YES  |     | NULL    |       |
# | User_Notes            | varchar(1000) | YES  |     | NULL    |       |
# | User_Feedback         | varchar(1)    | YES  |     | NULL    |       |
# | Concept_Review_Status | varchar(10)   | YES  |     | NULL    |       |
# | Document_Page_Number  | varchar(2)    | YES  |     | NULL    |       |
# | Creation_Date         | timestamp     | YES  |     | NULL    |       |
# | Last_Updated_Dts      | timestamp     | YES  |     | NULL    |       |
# | User_Name             | varchar(10)   | YES  |     | NULL    |       |
# +-----------------------+---------------+------+-----+---------+-------+
    

# mysql> describe patient;
# +----------------------+--------------+------+-----+---------+-------+
# | Field                | Type         | Null | Key | Default | Extra |
# +----------------------+--------------+------+-----+---------+-------+
# | Document_Identifier  | varchar(50)  | NO   | PRI | NULL    |       |
# | Patient_Id           | varchar(50)  | YES  |     | NULL    |       |
# | Patient_Name         | varchar(50)  | NO   |     | NULL    |       |
# | Patient_Gender       | varchar(10)  | YES  |     | NULL    |       |
# | Patient_DoB          | varchar(10)  | YES  |     | NULL    |       |
# | Patient_Address_line | varchar(150) | YES  |     | NULL    |       |
# | Patient_State        | varchar(2)   | YES  |     | NULL    |       |
# | Patient_Contact      | varchar(15)  | YES  |     | NULL    |       |
# +----------------------+--------------+------+-----+---------+-------+
# 8 rows in set (0.00 sec)
    
# mysql> describe provider;
# +-----------------------+--------------+------+-----+---------+-------+
# | Field                 | Type         | Null | Key | Default | Extra |
# +-----------------------+--------------+------+-----+---------+-------+
# | Document_Identifier   | varchar(50)  | NO   | PRI | NULL    |       |
# | Provider_Id           | varchar(50)  | YES  |     | NULL    |       |
# | Provider_Name         | varchar(50)  | NO   |     | NULL    |       |
# | Provider_Address_line | varchar(150) | YES  |     | NULL    |       |
# | Provider_State        | varchar(2)   | YES  |     | NULL    |       |
# | Provider_Contact      | varchar(15)  | YES  |     | NULL    |       |
# +-----------------------+--------------+------+-----+---------+-------+