import pytest
import json
from app import *
import jsoninputs

prov_jsoninput = jsoninputs.prov_getjson()

# prov_jsoninput = {
#         "Document_Identifier": "8db48a6d-79a3-418c-ba4e-370aa64a100c",
#         "Provider_Address_line": "Bond Street2",
#         "Provider_Contact": "10000000",
#         "Provider_Id": "76743ff2-5d7c-4514-b2dd-4c28ffb84100",
#         "Provider_Name": "Prov2",
#         "Provider_State": "IL"
# }

def test_index_route():
    response = app.test_client().get('/')

    #assert response.status_code == 200
    assert response.data.decode('utf-8') == "Server Works"

def test_prov_post_route():
   
    response = app.test_client().post('/pro',json=prov_jsoninput)

    
    sts = json.loads(response.data.decode('utf-8')).get("status")  
    assert sts == '100'
    

def test_prov_get_route():
    response = app.test_client().get('/pro')
    print('response:',response)

    sts = json.loads(response.data.decode('utf-8')).get("status")  
    assert sts == '100'
  

def test_prov_get_identifier_route():
    response = app.test_client().get('/pro/8db48a6d-79a3-418c-ba4e-370aa64a100c')

    sts = json.loads(response.data.decode('utf-8')).get("status")   
    assert sts == '100' 

def test_prov_del_identifier_route():
    response = app.test_client().delete('/pro/8db48a6d-79a3-418c-ba4e-370aa64a100c',json=prov_jsoninput)
  
    sts = json.loads(response.data.decode('utf-8')).get("status")
    assert sts == '100'
       
    





    