import pytest
import json
from app import *
import jsoninputs

app.json
cd_jsoninput =  jsoninputs.cd_getjson()
# cd_jsoninput = {
#         "Identifier": "cd_id4800",
#         "Document_Name" : "test.pdf",
#         "Document_Path" : "/test/test1/test.pdf",
#         "Document_Review_Status" : "TEST",
#         "Prior_Auth_Description" : "prior auth description",
#         "Patient_Document_id" : "doc5",
#         "Provider_Document_id" : "prov5",
#         "Document_Receive_dts" : "2024-02-20",
#         "Document_Evaluation_dts" : "2024-02-20",
#         "Last_Updated_dts" : "2024-02-20",
#         "User_Name" : 'sk1' 
# }

def test_index_route():
    response = app.test_client().get('/')

    #assert response.status_code == 200
    assert response.data.decode('utf-8') == "Server Works"

def test_cd_post_route():
   
    response = app.test_client().post('/cd',json=cd_jsoninput)

    
    sts = json.loads(response.data.decode('utf-8')).get("status")
    msg = json.loads(response.data.decode('utf-8')).get("msg")

    #assert sts == '100'
    assert msg == 'Record Inserted Sucessfully'

def test_cd_route():
    response = app.test_client().get('/cd')
    print('response:',response)

    sts = json.loads(response.data.decode('utf-8')).get("status")
    res = json.loads(response.data.decode('utf-8')).get("res")
    msg = json.loads(response.data.decode('utf-8')).get("msg")

    assert sts == '100'
    assert len(res) == msg
    assert len(res) > 0

def test_cd_get_identifier_route():
    response = app.test_client().get('/cd/cd_id4800')

    #assert response.status == '100'
    sts = json.loads(response.data.decode('utf-8')).get("status")
    res = json.loads(response.data.decode('utf-8')).get("res")
    msg = json.loads(response.data.decode('utf-8')).get("msg")
    assert sts == '100'
    assert len(res) == msg
    assert len(res) > 0

def test_cd_put_route():
    response = app.test_client().put('/cd/cd_id4800',json=cd_jsoninput)
    msg = json.loads(response.data.decode('utf-8')).get("msg")
   
    sts = json.loads(response.data.decode('utf-8')).get("status")
    assert sts == '100'
    assert msg == 'Record Updated Successfully'
    

    
    





    