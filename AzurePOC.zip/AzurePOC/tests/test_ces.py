import pytest
import json
from app import *
import jsoninputs

cd_jsoninput = jsoninputs.cd_getjson()
cds_jsoninput = jsoninputs.cds_getjson()
ces_jsoninput = jsoninputs.ces_getjson()

# cd_jsoninput = {
#         "Identifier": "cd_id4800",
#         "Document_Name" : "test.pdf",
#         "Document_Path" : "/test/test1/test.pdf",
#         "Document_Review_Status" : "TEST",
#         "Prior_Auth_Description" : "prior auth description",
#         "Patient_Document_id" : "doc5",
#         "Provider_Document_id" : "prov5",
#         "Document_Receive_dts" : "2024-02-20",
#         "Document_Evaluation_dts" : "2024-02-20",
#         "Last_Updated_dts" : "2024-02-20",
#         "User_Name" : 'sk1' 
# }

# cds_jsoninput = {
#         "CDS_Identifier": "35bf4898f6e84fe8a515ca53e73b",
#         "Concept_Name" : "Heart-Cardiac Condition2",
#         "Concept_Review_Status" : "/In-Progress",
#         "Creation_Date" : "Mon, 26 Feb 2024 17:32:42 GMT",
#         "Identifier" : "cd_id4800",
#         "Last_Updated_Dts" : "2024-03-02",
#         "User_Name" : "sk4",
#         "User_Notes" : "Note_Updated224"
#        }
# ces_jsoninput = {
#         "CDS_Identifier": "35bf4898f6e84fe8a515ca53e73b",
#         "CES_Identifier": "0607e12fe30b42de886df82cb8fc4zzz",
#         "Concept_LLM_Summary": "Concept_Summary123",
#         "Creation_Date": "2023-03-01",
#         "Document_Page_Number": "21",
#         "Last_Updated_Dts": "2023-03-01",
#         "Reference_Text": "disease_reference123",
#         "Response_Attribute": "response_text123",
#         "User_Feedback": "1",
#         "User_Name": "sk5"
#        }

def test_index_route():
    response = app.test_client().get('/')

    #assert response.status_code == 200
    assert response.data.decode('utf-8') == "Server Works"

def test_ces_post_route():
   
    response = app.test_client().post('/ces',json=ces_jsoninput)
    
    sts = json.loads(response.data.decode('utf-8')).get("status")
    assert sts == '100'
    

def test_ces_route():
    response = app.test_client().get('/ces')
    print('response:',response)

    sts = json.loads(response.data.decode('utf-8')).get("status")
    assert sts == '100'
    

def test_ces_get_cesidentifier_route():
    response = app.test_client().get('/ces/0607e12fe30b42de886df82cb8fc4zzz')

    #assert response.status == '100'
    sts = json.loads(response.data.decode('utf-8')).get("status")
    
    assert sts == '100'
   

def test_ces_put_cesidentifier_route():
    response = app.test_client().put('/ces/0607e12fe30b42de886df82cb8fc4zzz',json=ces_jsoninput)
      
    sts = json.loads(response.data.decode('utf-8')).get("status")
    assert sts == '100'
       
    
def test_ces_get_all():
    response = app.test_client().get('/allcds/35bf4898f6e84fe8a515ca53e73b')
        
    sts = json.loads(response.data.decode('utf-8')).get("status")
    assert sts == '100' 

def test_ces_get_cdidentifier_route():
    response = app.test_client().get('/cesid/35bf4898f6e84fe8a515ca53e73b')

    sts = json.loads(response.data.decode('utf-8')).get("status")
    
    assert sts == '100'
   

def test_ces_put_cdidentifier_route():
    response = app.test_client().put('/cesid/35bf4898f6e84fe8a515ca53e73b',json=ces_jsoninput)
      
    sts = json.loads(response.data.decode('utf-8')).get("status")
    assert sts == '100'
       
def test_ces_del_cesidentifier_route():
    response = app.test_client().delete('/ces/0607e12fe30b42de886df82cb8fc4zzz',json=ces_jsoninput)
        
    sts = json.loads(response.data.decode('utf-8')).get("status")
    assert sts == '100'

def test_ces_del_cdidentifier_route():
    app.test_client().post('/ces',json=ces_jsoninput)
    response = app.test_client().delete('/cesid/35bf4898f6e84fe8a515ca53e73b',json=ces_jsoninput)
    sts = json.loads(response.data.decode('utf-8')).get("status")
    assert sts == '100'

def test_cd_del_identifier_route():
    response = app.test_client().delete('/cd/cd_id4800',json=cd_jsoninput)
    msg = json.loads(response.data.decode('utf-8')).get("msg")

    #assert response.status == '100'
    sts = json.loads(response.data.decode('utf-8')).get("status")
    assert sts == '100'
    assert msg == 'Record Deleted Successfully'
    
def test_cds_del_identifier_route():
    response = app.test_client().delete('/cdsid/cd_id4800',json=cds_jsoninput)
    sts = json.loads(response.data.decode('utf-8')).get("status")
    assert sts == '100'

def test_cds_del_cdidentifier_route():

    app.test_client().post('/cds',json=cds_jsoninput)
    response = app.test_client().delete('/cds/35bf4898f6e84fe8a515ca53e73b',json=cds_jsoninput)
    sts = json.loads(response.data.decode('utf-8')).get("status")
    assert sts == '100' 

   
        


    





