import pytest
import json
from app import *
import jsoninputs

pat_jsoninput = jsoninputs.pat_getjson()

# pat_jsoninput = {
#         "Document_Identifier": "7a1fa8f0-e2d2-49b9-a227-baef02294d99",
#         "Patient_Address_line": "Street 999",
#         "Patient_Contact": "99999999",
#         "Patient_DoB": "25Jan2004",
#         "Patient_Gender": "Male",
#         "Patient_Id": "fa7d2fca-8e0a-4607-bac2-0a44bf92ae99",
#         "Patient_Name": "PAT2",
#         "Patient_State": "IL"
# }

def test_index_route():
    response = app.test_client().get('/')

    #assert response.status_code == 200
    assert response.data.decode('utf-8') == "Server Works"

def test_pat_post_route():
   
    response = app.test_client().post('/pat',json=pat_jsoninput)
    
    sts = json.loads(response.data.decode('utf-8')).get("status")

    assert sts == '100'
    

def test_pat_get_route():
    response = app.test_client().get('/pat')
    print('response:',response)

    sts = json.loads(response.data.decode('utf-8')).get("status")  
    assert sts == '100'
  

def test_pat_get_identifier_route():
    response = app.test_client().get('/pat/7a1fa8f0-e2d2-49b9-a227-baef02294d99')

    sts = json.loads(response.data.decode('utf-8')).get("status")   
    assert sts == '100'   

def test_pat_del_identifier_route():
    response = app.test_client().delete('/pat/7a1fa8f0-e2d2-49b9-a227-baef02294d99',json=pat_jsoninput)
  
    sts = json.loads(response.data.decode('utf-8')).get("status")
    assert sts == '100'
       
    





    