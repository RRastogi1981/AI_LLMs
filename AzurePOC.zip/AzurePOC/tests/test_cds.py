import pytest
import json
from app import *
import jsoninputs

cds_jsoninput = jsoninputs.cds_getjson()

# cds_jsoninput = {
#         "CDS_Identifier": "35bf4898f6e84fe8a515ca53e73b",
#         "Concept_Name" : "Heart-Cardiac Condition2",
#         "Concept_Review_Status" : "/In-Progress",
#         "Creation_Date" : "Mon, 26 Feb 2024 17:32:42 GMT",
#         "Identifier" : "cd_id4800",
#         "Last_Updated_Dts" : "2024-03-02",
#         "User_Name" : "sk4",
#         "User_Notes" : "Note_Updated224"
#        }

def test_index_route():
    response = app.test_client().get('/')

    #assert response.status_code == 200
    assert response.data.decode('utf-8') == "Server Works"

def test_cds_post_route():
   
    response = app.test_client().post('/cds',json=cds_jsoninput)
    
    sts = json.loads(response.data.decode('utf-8')).get("status")
    assert sts == '100'
    

def test_cds_route():
    response = app.test_client().get('/cds')
    print('response:',response)

    sts = json.loads(response.data.decode('utf-8')).get("status")
    assert sts == '100'
    

def test_cds_get_cdidentifier_route():
    response = app.test_client().get('/cds/35bf4898f6e84fe8a515ca53e73b')

    #assert response.status == '100'
    sts = json.loads(response.data.decode('utf-8')).get("status")
    
    assert sts == '100'
   

def test_cds_put_cdidentifier_route():
    response = app.test_client().put('/cds/35bf4898f6e84fe8a515ca53e73b',json=cds_jsoninput)
      
    sts = json.loads(response.data.decode('utf-8')).get("status")
    assert sts == '100'
       
        
    sts = json.loads(response.data.decode('utf-8')).get("status")
    assert sts == '100'
    
def test_cds_get_all():
    response = app.test_client().get('/all/cd_id4800')
        
    sts = json.loads(response.data.decode('utf-8')).get("status")
    assert sts == '100' 

def test_cds_get_identifier_route():
    response = app.test_client().get('/cdsid/cd_id4800')

    #assert response.status == '100'
    sts = json.loads(response.data.decode('utf-8')).get("status")
    
    assert sts == '100'
   

def test_cds_put_identifier_route():
    response = app.test_client().put('/cdsid/cd_id4800',json=cds_jsoninput)
      
    sts = json.loads(response.data.decode('utf-8')).get("status")
    assert sts == '100'
    

        


    





    