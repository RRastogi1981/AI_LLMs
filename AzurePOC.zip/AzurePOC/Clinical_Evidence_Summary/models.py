  
class clinical_evidence_summary:
    def __init__(self,CES_Identifier,
                      CDS_Identifier,
                      Concept_LLM_Summary,
                      Reference_Text,
                      Response_Attribute,
                      User_Feedback,
                      Document_Page_Number,
                      Creation_Date,
                      Last_Updated_Dts,
                      User_Name ):
    
      self.CES_Identifier = CES_Identifier
      self.CDS_Identifier = CDS_Identifier
      self.Concept_LLM_Summary = Concept_LLM_Summary
      self.Reference_Text = Reference_Text
      self.Response_Attribute = Response_Attribute
      self.User_Feedback = User_Feedback
      self.Document_Page_Number = Document_Page_Number
      self.Creation_Date = Creation_Date
      self.Last_Updated_Dts = Last_Updated_Dts
      self.User_Name = User_Name


    def __repr__(self):
        return '<id {}>'.format(self.CES_Identifier)

    def serialize(self):

        return {
    'CDS_Identifier' : self.CDS_Identifier,
    'CES_Identifier' : self.CES_Identifier,
    'Concept_LLM_Summary' : self.Concept_LLM_Summary,
    'Reference_Text' : self.Reference_Text,
    'Response_Attribute' : self.Response_Attribute,
    'User_Feedback' : self.User_Feedback,
    'Document_Page_Number' : self.Document_Page_Number,
    'Creation_Date' : self.Creation_Date,
    'Last_Updated_Dts' : self.Last_Updated_Dts,
    'User_Name' : self.User_Name
    }
  
