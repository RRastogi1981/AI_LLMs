from flask import Flask, render_template, request, jsonify
#from flask_restful import Resource, Api, marshal_with, fields
#from flask_sqlalchemy import SQLAlchemy
from connections import *
import json
#import os
from datetime import datetime
import Clinical_Evidence_Summary.models as model


def CES_insert_clinical_data(post_request):

    cursor = conn.cursor()
    now = datetime.now()
    #user= os.getlogin()
    #print(type(post_request),post_request)
    formatte_date = now.strftime('%Y-%m-%d %H:%M:%S')
    datas = model.clinical_evidence_summary(post_request['CES_Identifier'],
                                        post_request['CDS_Identifier'],
                                        post_request['Concept_LLM_Summary'],
                                        post_request['Reference_Text'],
                                        post_request['Response_Attribute'],
                                        post_request['User_Feedback'],
                                        post_request['Document_Page_Number'],
                                        post_request['Creation_Date'],
                                        post_request['Last_Updated_Dts'],
                                        post_request['User_Name'])
    #print(type(datas),datas)
    try:
        query= """INSERT INTO clinical_evidence_summary (
                CES_Identifier,
                CDS_Identifier,
                Concept_LLM_Summary,
                Reference_Text,
                Response_Attribute,
                User_Feedback,
                Document_Page_Number,
                Creation_Date,
                Last_Updated_Dts,
                User_Name         
            )
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""" 

        cursor.execute(query,(datas.CES_Identifier,datas.CDS_Identifier,datas.Concept_LLM_Summary,datas.Reference_Text,
                              datas.Response_Attribute,datas.User_Feedback,
                              datas.Document_Page_Number,datas.Creation_Date,datas.Last_Updated_Dts,datas.User_Name))
        
        conn.commit()
        return [True,'Inserted Sucessfully',datas]
               
    except Exception as e:
        #print(e)
        #print("Error while inserting data")
        text = "Error while inserting data:" + str(e)
        conn.rollback()
        return [False,text,datas]    
    cursor.close()
    


def CES_get_clinical_data():
    datas = []
    query = "select * from clinical_evidence_summary"
    cursor = conn.cursor()    
    cursor.execute(query)
    data=cursor.fetchall()
    for i in data:

        clinical_doc = model.clinical_evidence_summary(i[0],i[1], i[2],i[3],i[4],i[5],i[6],i[7],i[8],i[9])
        datas.append(clinical_doc)  
    return datas


def CES_clinical_document_by_ces_id(id, operation):
    datas = []
    cursor = conn.cursor()

    if operation == 'GET':
        query = "SELECT * FROM clinical_evidence_summary where CES_Identifier = %s ;"
        cursor.execute(query,(id,))
        data = cursor.fetchall()
        for i in data:
            clinical_doc =model.clinical_evidence_summary(i[0],i[1], i[2],i[3],i[4],i[5],i[6],i[7],i[8],i[9])  
            datas.append(clinical_doc)  

        cursor.close()
        #conn.close()
        return datas

    if operation == 'DELETE':
        cursor = conn.cursor()
        cursor.execute("DELETE FROM clinical_evidence_summary WHERE CES_Identifier = %s;", (id,))
        conn.commit()
        return "deleted"


def CES_clinical_document_put_by_ces_id(id, operation,request_data):

    if operation == 'PUT':
        cursor = conn.cursor()
        now = datetime.now()
        #user= os.getlogin()
        formatte_date = now.strftime('%Y-%m-%d %H:%M:%S')
        #print(type(request_data),request_data)
        data = model.clinical_evidence_summary(
                        id,
                        request_data['CDS_Identifier'],
                        request_data['Concept_LLM_Summary'],
                        request_data['Reference_Text'],
                        request_data['Response_Attribute'],
                        request_data['User_Feedback'],
                        request_data['Document_Page_Number'],
                        request_data['Creation_Date'],
                        formatte_date,
                        request_data['User_Name']
        )
        cursor.execute("UPDATE clinical_evidence_summary SET User_Feedback=%s,User_Name=%s,Last_Updated_Dts=%s WHERE CES_Identifier = %s ;",(data.User_Feedback,data.User_Name,data.Last_Updated_Dts,data.CES_Identifier))
        conn.commit()
        #conn.close()
        return "updated"
    
def CES_clinical_document_by_id(id, operation):
    datas = []
    cursor = conn.cursor()

    if operation == 'GET':
        query = "SELECT * FROM clinical_evidence_summary where CDS_Identifier = %s ;"
        cursor.execute(query,(id,))
        data = cursor.fetchall()
        for i in data:
            clinical_doc = model.clinical_evidence_summary(i[0],i[1], i[2],i[3],i[4],i[5],i[6],i[7],i[8],i[9])  
            datas.append(clinical_doc)  

        cursor.close()
        #conn.close()
        return datas

    if operation == 'DELETE':
        cursor = conn.cursor()
        cursor.execute("DELETE FROM clinical_evidence_summary WHERE CDS_Identifier = %s;", (id,))
        conn.commit()
        return "deleted"


def CES_clinical_document_put_by_id(id, operation,request_data):

    if operation == 'PUT':
        cursor = conn.cursor()
        now = datetime.now()
        #user= os.getlogin()
        formatte_date = now.strftime('%Y-%m-%d %H:%M:%S')
        #print(type(request_data),request_data)
        data = model.clinical_evidence_summary(
                        request_data['CES_Identifier'],
                        id,
                        request_data['Concept_LLM_Summary'],
                        request_data['Reference_Text'],
                        request_data['Response_Attribute'],
                        request_data['User_Feedback'],
                        request_data['Document_Page_Number'],
                        request_data['Creation_Date'],
                        formatte_date,
                        request_data['User_Name']

        )
        cursor.execute("UPDATE clinical_evidence_summary SET User_Feedback=%s,User_Name=%s,Last_Updated_Dts=%s WHERE CDS_Identifier = %s ;",(data.User_Feedback,data.User_Name,data.Last_Updated_Dts,data.CDS_Identifier))
        conn.commit()
        #conn.close()
        return "updated"    