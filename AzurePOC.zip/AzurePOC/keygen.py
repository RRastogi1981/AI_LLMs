import rsa
from datetime import datetime
from datetime import date


publicKey, privateKey = rsa.newkeys(2048) 

# Export public key in PKCS#1 format, PEM encoded 
publicKeyPkcs1PEM = publicKey.save_pkcs1().decode('utf8') 
#print(publicKeyPkcs1PEM)
with open('publickey.pem','w') as file:
    file.write(publicKeyPkcs1PEM)

# Export private key in PKCS#1 format, PEM encoded 
privateKeyPkcs1PEM = privateKey.save_pkcs1().decode('utf8') 
#print(privateKeyPkcs1PEM)
with open('privatekey.pem','w') as file:
    file.write(privateKeyPkcs1PEM)

with open('publickey.pem','r') as file:
    publicKeyPkcs1PEM = file.read()
publicKeyReloaded = rsa.PublicKey.load_pkcs1(publicKeyPkcs1PEM.encode('utf8'))


exp_date = date(2024, 12, 31)
exp_date=str(exp_date)
byt_encMessage = rsa.encrypt(exp_date.encode(),publicKeyReloaded)
with open('licence.txt','wb') as file:
    file.write(byt_encMessage)
