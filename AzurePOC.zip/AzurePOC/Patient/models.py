 
class patient:
    def __init__(self, Document_Identifier,
                        Patient_Id,
                        Patient_Name,
                        Patient_Gender,
                        Patient_DoB,
                        Patient_Address_line,
                        Patient_State,
                        Patient_Contact
                        ):
    
      self.Document_Identifier = Document_Identifier
      self.Patient_Id = Patient_Id
      self.Patient_Name = Patient_Name
      self.Patient_Gender = Patient_Gender
      self.Patient_DoB = Patient_DoB
      self.Patient_Address_line = Patient_Address_line
      self.Patient_State = Patient_State
      self.Patient_Contact = Patient_Contact

    def __repr__(self):
        return '<id {}>'.format(self.Document_Identifier)

    def serialize(self):

        return {
    'Document_Identifier' : self.Document_Identifier,
    'Patient_Id' : self.Patient_Id,
    'Patient_Name' : self.Patient_Name,
    'Patient_Gender' : self.Patient_Gender,
    'Patient_DoB' : self.Patient_DoB,
    'Patient_Address_line' : self.Patient_Address_line,
    'Patient_State' : self.Patient_State,
    'Patient_Contact' : self.Patient_Contact
    }
