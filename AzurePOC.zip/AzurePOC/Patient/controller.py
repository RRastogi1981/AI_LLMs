from flask import Flask, render_template, request, jsonify
#from flask_restful import Resource, Api, marshal_with, fields
#from flask_sqlalchemy import SQLAlchemy
from connections import * 
import json
#import os
from datetime import datetime
import Patient.models as model


def Pat_insert_clinical_data(post_request):
    
    cursor = conn.cursor()
    datas = model.patient(post_request['Document_Identifier'],
                    post_request['Patient_Id'],
                    post_request['Patient_Name'],
                    post_request['Patient_Gender'],
                    post_request['Patient_DoB'],
                    post_request['Patient_Address_line'],
                    post_request['Patient_State'],
                    post_request['Patient_Contact']
                               )
    try:
        query= """INSERT INTO patient (
                                                Document_Identifier,
                                                Patient_Id,
                                                Patient_Name,
                                                Patient_Gender,
                                                Patient_DoB,
                                                Patient_Address_line,
                                                Patient_State,
                                                Patient_Contact)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s)""" 

        cursor.execute(query,(datas.Document_Identifier,datas.Patient_Id,datas.Patient_Name,
                              datas.Patient_Gender,datas.Patient_DoB,datas.Patient_Address_line
                              ,datas.Patient_State,datas.Patient_Contact))
        conn.commit()    
    except Exception as e:
        print(e)
        print("Error while inserting data")
        conn.rollback()
    cursor.close()

    return datas


def Pat_get_clinical_data():
    datas = []
    query = "select * from patient"
    cursor = conn.cursor()
    cursor.execute(query)
    data=cursor.fetchall()
    for i in data:

        clinical_doc = model.patient(i[0],i[1], i[2],i[3],i[4],i[5],i[6],i[7])
        datas.append(clinical_doc)  
    return datas


def Pat_clinical_document_by_id(id, operation):
    datas = []
    cursor = conn.cursor()

    if operation == 'GET':
        query = "SELECT * FROM patient where Document_Identifier = %s ;"
        cursor.execute(query,(id,))
        data = cursor.fetchall()
        for i in data:
            clinical_doc = model.patient(i[0],i[1], i[2],i[3],i[4],i[5],i[6],i[7])  
            datas.append(clinical_doc)  

        cursor.close()
        #conn.close()
        return datas

    if operation == 'DELETE':
        cursor = conn.cursor()
        cursor.execute("DELETE FROM patient WHERE Document_Identifier = %s;", (id,))
        conn.commit()
        return "deleted"

'''
def clinical_document_put_by_id(id, operation,request_data):

    if operation == 'PUT':
        cursor = conn.cursor()
        now = datetime.now()
        user= os.getlogin()
        formatte_date = now.strftime('%Y-%m-%d %H:%M:%S')
        print(type(request_data),request_data)
        data = patient(id,
                        request_data['Patient_Id'],
                        request_data['Patient_Name'],
                        request_data['Patient_Gender'],
                        request_data['Patient_DoB'],
                        request_data['Patient_Address_line'],
                        request_data['Patient_State'],
                        request_data['Patient_Contact'],
                        )
        cursor.execute("UPDATE clinical_document SET Document_Review_Status = %s,Last_Updated_dts =%s,User_Name=%s WHERE Document_Identifier = %s ;",(data.Document_Review_Status, data.Last_Updated_dts,data.User_Name,id))
        conn.commit()
        #conn.close()
        return "updated"
    
    '''