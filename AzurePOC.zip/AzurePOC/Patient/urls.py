#from flask_restful import Resource, Api, marshal_with, fields
#from flask_sqlalchemy import SQLAlchemy
#from connections import *
from Patient.controller import *
from app import app


@app.route('/pat', methods=['POST'])
def Pat_post_request():
    post_request = request.get_json()
    print(post_request)
    try:
        response = (Pat_clinical_document_by_id(post_request['Document_Identifier'], 'GET'))
        print(response)
        clinical_doc = [b.serialize() for b in response]
        if (len(clinical_doc)==0):
            response = Pat_insert_clinical_data(post_request)
            print(type(response))
            return  jsonify({
                'status': '100',
                'res': post_request,
            '   msg': 'Inserted Sucessfully'})
        else:
            return  jsonify({
                'status': '200',
            'res': post_request,
            '   msg': 'ID already existing - Insert failed'})
    
    except Exception as e:
        print(e)
        print("Error while inserting data")


@app.route('/pat',methods=['GET'])
def Pat_get_request():

    response = Pat_get_clinical_data()
    clinical_doc = [b.serialize() for b in response]
    if (len(clinical_doc)==0):
        return  jsonify({
            'status': '200',
            'res': '',
            'msg': 'No Data Present'})
    else:
        return  jsonify({
            'status': '100',
            'res': clinical_doc,
            'msg': len(clinical_doc)})
    

@app.route('/pat/<string:id>', methods=['GET', 'DELETE', 'PUT'])
def Pat_id_request(id):
        
    response = Pat_clinical_document_by_id(id,'GET')
    print(type(response))
    clinical_doc = [b.serialize() for b in response]
    #print(clinical_doc)
    if request.method == 'GET':
        if (len(clinical_doc)==0):
            return  jsonify({
            'status': '200',
            'res': '',
            'msg': 'No Data Present'})
        else:
            return  jsonify({
            'status': '100',
            'res': clinical_doc,
            'msg': len(clinical_doc)})
    
    if request.method == 'DELETE':
        if (len(clinical_doc)==0):
            return  jsonify({
            'status': '200',
            'res': id,
            'msg': 'No Data Present to Delete'})
        else:
            response = Pat_clinical_document_by_id(id,str(request.method))
            return  jsonify({
            'status': '100',
            'res': clinical_doc,
            'msg': "Record Deleted Successfully"})
        
