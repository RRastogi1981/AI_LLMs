import json

def cd_getjson():
    cd_jsoninput = {
        "Identifier": "cd_id4800",
        "Document_Name" : "test.pdf",
        "Document_Path" : "/test/test1/test.pdf",
        "Document_Review_Status" : "TEST",
        "Prior_Auth_Description" : "prior auth description",
        "Patient_Document_id" : "doc5",
        "Provider_Document_id" : "prov5",
        "Document_Receive_dts" : "2024-02-20",
        "Document_Evaluation_dts" : "2024-02-20",
        "Last_Updated_dts" : "2024-02-20",
        "User_Name" : 'sk1' 
}
    return cd_jsoninput

def cds_getjson():
    cds_jsoninput = {
        "CDS_Identifier": "35bf4898f6e84fe8a515ca53e73b",
        "Concept_Name" : "Heart-Cardiac Condition2",
        "All_Evidence_Summary" : "Test",
        "All_Evidence_Feedback": "1",
        "Concept_Review_Status" : "/In-Progress",
        "Creation_Date" : "Mon, 26 Feb 2024 17:32:42 GMT",
        "Identifier" : "cd_id4800",
        "Last_Updated_Dts" : "2024-03-02",
        "User_Name" : "sk4",
        "User_Notes" : "Note_Updated224"
       }
    return cds_jsoninput

def ces_getjson():
    ces_jsoninput = {
        "CDS_Identifier": "35bf4898f6e84fe8a515ca53e73b",
        "CES_Identifier": "0607e12fe30b42de886df82cb8fc4zzz",
        "Concept_LLM_Summary": "Concept_Summary123",
        "Creation_Date": "2023-03-01",
        "Document_Page_Number": "21",
        "Last_Updated_Dts": "2023-03-01",
        "Reference_Text": "disease_reference123",
        "Response_Attribute": "response_text123",
        "User_Feedback": "1",
        "User_Name": "sk5"
       }
    return ces_jsoninput

def pat_getjson():
    pat_jsoninput = {
        "Document_Identifier": "7a1fa8f0-e2d2-49b9-a227-baef02294d99",
        "Patient_Address_line": "Street 999",
        "Patient_Contact": "99999999",
        "Patient_DoB": "25Jan2004",
        "Patient_Gender": "Male",
        "Patient_Id": "fa7d2fca-8e0a-4607-bac2-0a44bf92ae99",
        "Patient_Name": "PAT2",
        "Patient_State": "IL"
}
    return pat_jsoninput

def prov_getjson():
    prov_jsoninput = {
        "Document_Identifier": "8db48a6d-79a3-418c-ba4e-370aa64a100c",
        "Provider_Address_line": "Bond Street2",
        "Provider_Contact": "10000000",
        "Provider_Id": "76743ff2-5d7c-4514-b2dd-4c28ffb84100",
        "Provider_Name": "Prov2",
        "Provider_State": "IL"
}
    return prov_jsoninput




    
