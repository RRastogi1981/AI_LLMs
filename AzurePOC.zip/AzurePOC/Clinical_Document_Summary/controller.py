from flask import Flask, render_template, request, jsonify
#from flask_restful import Resource, Api, marshal_with, fields
#from flask_sqlalchemy import SQLAlchemy
from connections import *
import json
#import os
from datetime import datetime
import Clinical_Document_Summary.models as model


def CDS_insert_clinical_data(post_request):

    cursor = conn.cursor()
    now = datetime.now()
    #user= os.getlogin()
    #print(type(post_request),post_request)
    formatte_date = now.strftime('%Y-%m-%d %H:%M:%S')
    datas = model.clinical_document_summary(post_request['CDS_Identifier'],
                                        post_request['Identifier'],
                                        post_request['Concept_Name'],
                                        post_request['All_Evidence_Summary'],
                                        post_request['All_Evidence_Feedback'],
                                        post_request['User_Notes'],
                                        post_request['Concept_Review_Status'],
                                        post_request['Creation_Date'],
                                        post_request['Last_Updated_Dts'],
                                        post_request['User_Name'])
    #print(type(datas),datas)
    try:
        query= """INSERT INTO clinical_document_summary (
                CDS_Identifier,
                Identifier,
                Concept_Name,
                All_Evidence_Summary,
                All_Evidence_Feedback,
                User_Notes,
                Concept_Review_Status,
                Creation_Date,
                Last_Updated_Dts,
                User_Name         
            )
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""" 

        cursor.execute(query,(datas.CDS_Identifier,datas.Identifier,datas.Concept_Name,datas.All_Evidence_Summary,datas.All_Evidence_Feedback,
                              datas.User_Notes,datas.Concept_Review_Status,
                              datas.Creation_Date,datas.Last_Updated_Dts,datas.User_Name))
        
        conn.commit()
        return [True,'Inserted Sucessfully',datas]
               
    except Exception as e:
        #print(e)
        #print("Error while inserting data")
        text = "Error while inserting data:" + str(e)
        conn.rollback()
        return [False,text,datas]    
    cursor.close()
    


def CDS_get_clinical_data():
    datas = []
    query = "select * from clinical_document_summary"
    cursor = conn.cursor()    
    cursor.execute(query)
    data=cursor.fetchall()
    for i in data:

        clinical_doc = model.clinical_document_summary(i[0],i[1], i[2],i[3],i[4],i[5],i[6],i[7],i[8],i[9])
        datas.append(clinical_doc)  
    return datas


def CDS_clinical_document_by_cds_id(id, operation):
    datas = []
    cursor = conn.cursor()

    if operation == 'GET':
        query = "SELECT * FROM clinical_document_summary where CDS_Identifier = %s ;"
        cursor.execute(query,(id,))
        data = cursor.fetchall()
        for i in data:
            clinical_doc =model.clinical_document_summary(i[0],i[1], i[2],i[3],i[4],i[5],i[6],i[7],i[8],i[9])  
            datas.append(clinical_doc)  

        cursor.close()
        #conn.close()
        return datas

    if operation == 'DELETE':
        cursor = conn.cursor()
        cursor.execute("DELETE FROM clinical_document_summary WHERE CDS_Identifier = %s;", (id,))
        conn.commit()
        return "deleted"


def CDS_clinical_document_put_by_cds_id(id, operation,request_data):

    if operation == 'PUT':
        cursor = conn.cursor()
        now = datetime.now()
        #user= os.getlogin()
        formatte_date = now.strftime('%Y-%m-%d %H:%M:%S')
        #print(type(request_data),request_data)
        data = model.clinical_document_summary(
                        id,
                        request_data['Identifier'],
                        request_data['Concept_Name'],
                        request_data['All_Evidence_Summary'],
                        request_data['All_Evidence_Feedback'],
                        request_data['User_Notes'],
                        request_data['Concept_Review_Status'],
                        request_data['Creation_Date'],
                        formatte_date,
                        request_data['User_Name']
        )
        cursor.execute("UPDATE clinical_document_summary SET All_Evidence_Feedback = %s, Concept_Review_Status = %s,User_Notes =%s,User_Name=%s,Last_Updated_Dts=%s WHERE CDS_Identifier = %s ;",(data.All_Evidence_Feedback,data.Concept_Review_Status,data.User_Notes ,data.User_Name,data.Last_Updated_Dts,data.CDS_Identifier))
        conn.commit()
        #conn.close()
        return "updated"
    
def CDS_clinical_document_by_id(id, operation):
    datas = []
    cursor = conn.cursor()

    if operation == 'GET':
        query = "SELECT * FROM clinical_document_summary where Identifier = %s ;"
        cursor.execute(query,(id,))
        data = cursor.fetchall()
        for i in data:
            clinical_doc = model.clinical_document_summary(i[0],i[1], i[2],i[3],i[4],i[5],i[6],i[7],i[8],i[9])  
            datas.append(clinical_doc)  

        cursor.close()
        #conn.close()
        return datas

    if operation == 'DELETE':
        cursor = conn.cursor()
        cursor.execute("DELETE FROM clinical_document_summary WHERE Identifier = %s;", (id,))
        conn.commit()
        return "deleted"


def CDS_clinical_document_put_by_id(id, operation,request_data):

    if operation == 'PUT':
        cursor = conn.cursor()
        now = datetime.now()
        #user= os.getlogin()
        formatte_date = now.strftime('%Y-%m-%d %H:%M:%S')
        #print(type(request_data),request_data)
        data = model.clinical_document_summary(
                        request_data['CDS_Identifier'],
                        id,
                        request_data['Concept_Name'],
                        request_data['All_Evidence_Summary'],
                        request_data['All_Evidence_Feedback'],
                        request_data['User_Notes'],
                        request_data['Concept_Review_Status'],
                        request_data['Creation_Date'],
                        formatte_date,
                        request_data['User_Name']

        )
        cursor.execute("UPDATE clinical_document_summary SET All_Evidence_Feedback = %s,Concept_Review_Status = %s,User_Notes =%s,User_Name=%s,Last_Updated_Dts=%s WHERE Identifier = %s ;",(data.All_Evidence_Feedback,data.Concept_Review_Status,data.User_Notes,data.User_Name,data.Last_Updated_Dts ,data.Identifier))
        conn.commit()
        #conn.close()
        return "updated"    