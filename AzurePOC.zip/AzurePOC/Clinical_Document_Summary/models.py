  
class clinical_document_summary:
    def __init__(self,CDS_Identifier,
                      Identifier,
                      Concept_Name,
                      All_Evidence_Summary,
                      All_Evidence_Feedback,
                      User_Notes,
                      Concept_Review_Status,
                      Creation_Date,
                      Last_Updated_Dts,
                      User_Name ):
    
      self.CDS_Identifier = CDS_Identifier
      self.Identifier = Identifier
      self.Concept_Name = Concept_Name
      self.All_Evidence_Summary = All_Evidence_Summary
      self.All_Evidence_Feedback = All_Evidence_Feedback
      #self.Concept_LLM_Summary = Concept_LLM_Summary
      #self.Reference_Text = Reference_Text
      #self.Response_Attribute = Response_Attribute
      self.User_Notes = User_Notes
      #self.User_Feedback = User_Feedback
      self.Concept_Review_Status = Concept_Review_Status
      #self.Document_Page_Number = Document_Page_Number
      self.Creation_Date = Creation_Date
      self.Last_Updated_Dts = Last_Updated_Dts
      self.User_Name = User_Name


    def __repr__(self):
        return '<id {}>'.format(self.Identifier)

    def serialize(self):

        return {
    'CDS_Identifier' : self.CDS_Identifier,
    'Identifier' : self.Identifier,
    'Concept_Name' : self.Concept_Name,
    'All_Evidence_Summary' : self.All_Evidence_Summary,
    'All_Evidence_Feedback': self.All_Evidence_Feedback,
    'User_Notes' : self.User_Notes,
    'Concept_Review_Status' : self.Concept_Review_Status,
    'Creation_Date' : self.Creation_Date,
    'Last_Updated_Dts' : self.Last_Updated_Dts,
    'User_Name' : self.User_Name
    }
  
