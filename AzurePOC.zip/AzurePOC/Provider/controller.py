from flask import Flask, render_template, request, jsonify
#from flask_restful import Resource, Api, marshal_with, fields
#from flask_sqlalchemy import SQLAlchemy
from connections import *
import json
import os
from datetime import datetime
import Provider.models as model


def Pro_insert_clinical_data(post_request):
    
    cursor = conn.cursor()
    
    datas = model.provider(post_request['Document_Identifier'],
                              post_request['Provider_Id'],
                              post_request['Provider_Name'],
                              post_request['Provider_Address_line'],
                              post_request['Provider_State'],
                              post_request['Provider_Contact'])
    try:
        query= """INSERT INTO provider (
                            Document_Identifier,
                            Provider_Id,
                            Provider_Name,
                            Provider_Address_line,
                            Provider_State,
                            Provider_Contact)
                VALUES (%s,%s,%s,%s,%s,%s)""" 

        cursor.execute(query,(datas.Document_Identifier,datas.Provider_Id,datas.Provider_Name,
                              datas.Provider_Address_line,datas.Provider_State,datas.Provider_Contact))
        conn.commit()    
    except Exception as e:
        print(e)
        print("Error while inserting data")
        conn.rollback()
    cursor.close()

    return datas


def Pro_get_clinical_data():
    datas = []
    query = "select * from provider"
    cursor = conn.cursor()
    cursor.execute(query)
    data=cursor.fetchall()
    for i in data:

        clinical_doc = model.provider(i[0],i[1], i[2],i[3],i[4],i[5])
        datas.append(clinical_doc)  
    return datas


def Pro_clinical_document_by_id(id, operation):
    datas = []
    cursor = conn.cursor()

    if operation == 'GET':
        query = "SELECT * FROM provider where Document_Identifier = %s ;"
        cursor.execute(query,(id,))
        data = cursor.fetchall()
        for i in data:
            clinical_doc = model.provider(i[0],i[1], i[2],i[3],i[4],i[5])  
            datas.append(clinical_doc)  

        cursor.close()
        #conn.close()
        return datas

    if operation == 'DELETE':
        cursor = conn.cursor()
        cursor.execute("DELETE FROM provider WHERE Document_Identifier = %s;", (id,))
        conn.commit()
        return "deleted"
