
class provider:
    def __init__(self, Document_Identifier,
                        Provider_Id,
                        Provider_Name,
                        Provider_Address_line,
                        Provider_State,
                        Provider_Contact):
      self.Document_Identifier = Document_Identifier
      self.Provider_Id = Provider_Id
      self.Provider_Name = Provider_Name
      self.Provider_Address_line = Provider_Address_line
      self.Provider_State = Provider_State
      self.Provider_Contact = Provider_Contact

      
    def __repr__(self):
      return '<id {}>'.format(self.Document_Identifier)

    def serialize(self):

      return {
      'Document_Identifier' : self.Document_Identifier,
      'Provider_Id' : self.Provider_Id,
      'Provider_Name' : self.Provider_Name,
      'Provider_Address_line' : self.Provider_Address_line,
      'Provider_State' : self.Provider_State,
      'Provider_Contact' : self.Provider_Contact   
    }