import uuid
import yaml
from azure.keyvault.secrets import SecretClient
from azure.identity import DefaultAzureCredential
import rsa
from datetime import datetime
from datetime import date


def getNewId():
    result = uuid.uuid4()
    return result.hex

def read_yaml_file():
    file_path= 'application.yml'
    with open(file_path, 'r') as yaml_file:
        data= yaml.safe_load(yaml_file)
    return data

def access_element(data, target):
    for key, value in data.items():
        if key == target:
            return value
        elif isinstance(value, dict):
            result= access_element(value, target)
            if result is not None:
                return result
    return None

def get_keyvault_value(keyVaultName,secret):
    credential = DefaultAzureCredential()
    KVUri = f"https://{keyVaultName}.vault.azure.net"
    client = SecretClient(vault_url=KVUri, credential=credential)
    retrieved_secret = client.get_secret(secret)
    return retrieved_secret.value

def licence_validate():

    format = '%Y-%m-%d'
    with open('privatekey.pem','r') as file:
        privateKeyPkcs1PEM = file.read()
    privateKeyReloaded = rsa.PrivateKey.load_pkcs1(privateKeyPkcs1PEM.encode('utf8'))

    with open('licence.txt','rb') as file:
        data = file.read()

    decMessage = rsa.decrypt(data, privateKeyReloaded).decode()
    exp_date = datetime.strptime(decMessage, format)
    today_date = datetime.today()
    if today_date < exp_date:
        delta = exp_date - today_date
        if delta.days < 20:
            print("Less Time")
        print(True)
    else:
        print(False)

licence_validate()
#data= read_yaml_file()
#test = 'Development'
#print(data[test]['DB_NAME'])

