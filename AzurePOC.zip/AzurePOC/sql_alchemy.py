import pymysql
from sqlalchemy import create_engine
import mysql.connector

#cnx = create_engine('mysql+pymysql://devadmin:admin@12345678@http://127.0.0.1/ccpdb?host=localhost?port=5000')  
#cnx= create_engine("mysql+pymysql://devadmin:admin@12345678@sqlserverdev.mysql.database.azure.com/ccpdb",
#                       connect_args= dict(host='sqlserverdev.mysql.database.azure.com', port=3306))  


# Connect to the database
import urllib.parse
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session

password = urllib.parse.quote_plus("User@12345678") 
print(password)
ca_path="C:\\Users\\devadmin\\Documents\\AzurePOC\\DigiCertGlobalRootCA.crt.pem"
ssl_args = {'ssl_ca': ca_path}
user ='demouser'
pw = urllib.parse.quote_plus("User@12345678")
host= 'sqlserverdev.mysql.database.azure.com:3306'
database ='ccpdb'
#engine = create_engine("mysql://demouser:{}@sqlserverdev.mysql.database.azure.com:3306/ccpdb".format(password))
#engine = create_engine("mysql+pymysql://devadmin:admin_12345678@sqlserverdev.mysql.database.azure.com:3306/ccpdb".format(password))
connect_args={'ssl':{'fake_flag_to_enable_tls': True}}
connect_string = 'mysql+pymysql://{}:{}@{}/{}'.format(user,pw,host,database)
print(connect_string)
engine = create_engine(connect_string,connect_args=connect_args) 
# Test the connection
Base = automap_base()
Base.prepare(engine, reflect=True)
print(engine)
#conn = engine.connect()
#conn = cnx.connect()
#print(conn)
Users = Base.classes.clinical_document
session = Session(engine)
res = session.query(Users).first()
print(type(res),res)

#query = "select * from clinical_document"
#cursor = conn.cursor()
#cursor.execute(query)
#data=cursor.fetchall()
#print(data)

#df = pd.read_sql('SELECT * FROM <table_name>', cnx)