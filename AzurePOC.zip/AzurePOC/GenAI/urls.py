from flask import Flask, render_template, request, jsonify
from app import app
from GenAI.controller import *






@app.route('/genai', methods=['GET'])
def execute_genai_process():
    # get_llm_response()
    try:
        get_llm_response()
    except Exception as ex:
        return jsonify({
            'status': '500',
            'msg': f"GenAI process failed with exception {ex}"
        })
    else:
        return  jsonify({
                'status': '200',
                'msg': "GenAI process executed Successfully"})



    

    


    

    













