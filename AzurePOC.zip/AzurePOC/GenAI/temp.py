from utilities.azure import retrieve_blob

connection_string = 'DefaultEndpointsProtocol=https;AccountName=cenblob001;AccountKey=JE1UdqcxuiOvUzgNuSmkEEtIG7aUGb7SNbvrBtSV6l3ROqg5hUZMVv2GxK3taQs5fGc/aO/R2v1/+ASt+1013w==;EndpointSuffix=core.windows.net'
    # container=os.getenv('container_name')
container = 'ccpcont-processed-pdf-to-json'
retrieve_file=retrieve_blob(connection_string=connection_string,
                            container=container
    )
retrieve_file.retrieve_file(filename=None)
