import requests
import os
import json
from Clinical_Document_Summary.controller import CDS_insert_clinical_data
from Clinical_Document.controller import CD_insert_clinical_data
from Clinical_Evidence_Summary.controller import CES_insert_clinical_data
from Patient.controller import Pat_insert_clinical_data
from Provider.controller import Pro_insert_clinical_data

class DB:

    def __init__(self)->None:
        # cds_endpoint=os.getenv('PostToCDSEndPoint')
        # ces_endpoint=os.getenv('PostToCESEndPoint')
        # cd_endpoint=os.getenv('PostToCDEndpoint')
        # pat_endpoint=os.getenv('PostToPatientEndpoint')
        # provider_endpoint=os.getenv('PostToProviderEndPoint')
        pass

    def posttocds(self,cdsdict:dict)->None:
        # url=self.cds_endpoint
        # headers = {'Accept-Charset': 'utf-8','Accept':'application/json','accept-encoding' : 'gzip','Content-Type':'application/json'}
        # put_cl_data =json.dumps(cdsdict)

        # response = requests.post(url, data=put_cl_data, headers=headers)
        # print(response.text)
        CDS_insert_clinical_data(cdsdict)

    def posttoces(self,cesdict:dict)->None:
        # url = self.ces_endpoint
        # headers = {'Accept-Charset': 'utf-8','Accept':'application/json','accept-encoding' : 'gzip','Content-Type':'application/json'}
        # put_cl_data =json.dumps(cesdict)

        # response = requests.post(url, data=put_cl_data, headers=headers)
        # print(response.text)
        CES_insert_clinical_data(cesdict)
    
    def posttocd(self,cdDic:dict):
        # url = self.cd_endpoint
        # headers = {'Accept-Charset': 'utf-8','Accept':'application/json','accept-encoding' : 'gzip','Content-Type':'application/json'}
        # data1 =json.dumps(cdDic)
        # response = requests.post(url, data=data1, headers=headers)
        # print(response.text)
        CD_insert_clinical_data(cdDic)

    def postToPatientdb(self,patDict:dict):
        # url = self.pat_endpoint
        # headers = {'Accept-Charset': 'utf-8','Accept':'application/json','accept-encoding' : 'gzip','Content-Type':'application/json'}
        # data1 =json.dumps(patDict)
        # response = requests.post(url, data=data1, headers=headers)
        # print(response.text)
        Pat_insert_clinical_data(patDict)

    def postToProviderdb(self,proDict:dict):
        # url = self.provider_endpoint
        # headers = {'Accept-Charset': 'utf-8','Accept':'application/json','accept-encoding' : 'gzip','Content-Type':'application/json'}
        # data1 =json.dumps(proDict)
        # response = requests.post(url, data=data1, headers=headers)
        # print(response.text)
        Pro_insert_clinical_data(proDict)