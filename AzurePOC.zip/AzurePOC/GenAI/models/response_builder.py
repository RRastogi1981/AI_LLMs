from pydantic import BaseModel, ValidationError
from GenAI.models.prompt_builder import promptcreator
from GenAI.models.program_builder import program
from GenAI.llm_response.qna import QnA

class responseModel(BaseModel):
    """Data model for the LLM Response"""
    generated_text: str
    reference_text: str
    attributes: dict[str,str]


class response():
   
    def __init__(self,PromptPath:str,
                 MedicalRecord:dict,
                 program:program)-> None:
        
        self.Promptpath=PromptPath
        self.program = program
        self.MedicalRecord=MedicalRecord
    

    
    def generateResponse(self, concepts:dict)->dict:
        response_dict = {}
        
        for conceptid in concepts:
            PromptFile = self.Promptpath+concepts[conceptid]+".txt"
            page_evidence = {}
            
            for page in self.MedicalRecord:
                #Code to be commented
                # if(int(page)>2 and int(page)<5):
                if(int(page)>2):
                    prompt_builder=promptcreator(PromptFile,self.MedicalRecord[page])
                    prompt = prompt_builder.promptbuilder()
                    
                    respond = self.program.programrespond(prompt)
                    response = respond()                
                    page_evidence[page] = response
            response_dict[conceptid]=page_evidence
        return response_dict

