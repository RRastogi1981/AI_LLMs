import os
from GenAI.utilities.yamlUtility import read_yaml_file
from datetime import datetime
yamlRead:dict = read_yaml_file()

def writeToLog(textstring:str):
    filepath = yamlRead['GenAI']['GenAILogFilePath']
    now = datetime.now()
    formatted_date = now.strftime('%Y-%m-%d %H:%M:%S')
    textstring = formatted_date + " : " + textstring
    if(os.path.isfile(filepath)):
        f = open(filepath,"a")
        f.write("\n"+textstring)
        f.close()
    else:
        f = open(filepath,"w")
        f.write(textstring)
        f.close()