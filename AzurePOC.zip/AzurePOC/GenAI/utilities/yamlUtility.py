import yaml

def read_yaml_file():
    file_path= './application.yml'
    with open(file_path, 'r') as yaml_file:
        data= yaml.safe_load(yaml_file)
    return data

