import json
from GenAI.models.program_builder import program 
from GenAI.models.prompt_builder import promptcreator
from GenAI.models.response_builder import responseModel,response
from GenAI.models.pat_pro_model import PatientModel,ProviderModel
from GenAI.models.concept_summary_model import ConceptSummaryModel
from GenAI.utilities.azure import *
from GenAI.llm_response.qna import ExlAI, QnA
import os
import uuid
from datetime import datetime
import getpass as gt
from GenAI.dboperations.db_utility import DB
from GenAI.utilities.datetime_utilities import file_creation_date
from GenAI.utilities.yamlUtility import read_yaml_file
from GenAI.utilities.log_write_util import writeToLog
yamlRead:dict = read_yaml_file()

def retreive_auth_requests(filename:str=None):
    '''Retreives the prior authorization requests from the designated azure blob'''

    connection_string = yamlRead["GenAI"]["AzureConnectionString"]
    container = yamlRead["GenAI"]['container_name']
    retrieve_file=retrieve_blob(connection_string=connection_string,
                            container=container
                            )
    retrieve_file.retrieve_file(filename=filename)

def uploadToJsonArchive(filename:str=None):
     connection_string = yamlRead["GenAI"]["JsonArchiveConnectionString"]
     container =yamlRead['GenAI']["JsonArchiveContainerName"]
     upload_file = upload_blob(connection_string=connection_string,container=container)
     upload_file.upload_file(filename=filename)

def deleteFromJsonSource(filename:str=None):
     connection_string = yamlRead['GenAI']["AzureConnectionString"]
     container = yamlRead["GenAI"]["container_name"]
     delete_file = delete_blob(connection_string=connection_string,container=container)
     delete_file.del_file(filename=filename)

def get_llm_response():

    username = gt.getuser()
    retreive_auth_requests()
    # print("Files downloaded")
    writeToLog("Files downloaded")
    with open('GenAI/concepts.json','r') as concept_file:
        concepts:dict=json.loads(concept_file.read())
    # print("Concepts file read successfully")
    writeToLog("Concepts file read successfully")
    PromptPath = yamlRead["GenAI"]['PromptPath']
    prior_auth_locations = yamlRead["GenAI"]['DataFolder']

    PatientPromptPath:str = yamlRead["GenAI"]['PatientPromptPath']
    ProviderPromptPath:str = yamlRead["GenAI"]['ProviderPromptPath']
    conceptSummarizePromptPath:str = yamlRead["GenAI"]['conceptSummaryPromptPath']

    #Initiate the generate_sas_url object
    PdfContainerAccountName:str = yamlRead["GenAI"]['PdfArchiveAccountName']
    PdfContainerAccountKey:str = yamlRead["GenAI"]['PdfArchiveAccountKey']
    PdfContainer:str = yamlRead["GenAI"]['PdfArchiveAccountContainer']
    generateSasUrlObj:generate_sas_url = generate_sas_url(PdfContainerAccountName,PdfContainerAccountKey,PdfContainer)

    db_object=DB()

    
    for filename in os.listdir(prior_auth_locations):
        # print(f"Processing of {filename} started")
        document_id = str(uuid.uuid4())
        print(f"Document id for the {filename}:{document_id}")
        writeToLog(f"Document id for the {filename}:{document_id}")

        Doc_sas_path:str =  generateSasUrlObj.generate_sas_token(filename)
        creation_datetime =file_creation_date(os.path.join(prior_auth_locations, filename))
        #Hard Coded value for Prior_Auth_Description
        cd_data = {
                    'Identifier':document_id,
                    'Document_Name': filename,
                    'Document_Path':Doc_sas_path,
                    'Document_Review_Status':"Not-Started",
                    'Prior_Auth_Description':'Actemra Prior Auth',
                    'Patient_Document_id':document_id,
                    'Provider_Document_id':document_id,
                    'Document_Receive_dts': creation_datetime,
                    'Document_Evaluation_dts': creation_datetime,
                    'Last_Updated_dts': creation_datetime,
                    'User_Name':username
                    }
        
        cds_data= {
            'All_Evidence_Feedback':0,
            'All_Evidence_Summary':'',
            'CDS_Identifier':'',
            'Identifier':document_id,
            'Concept_Name': '',
            'User_Notes':'',
            'Concept_Review_Status': 'Not-Started',
            'Creation_Date': '2024-02-20',
            'Last_Updated_Dts': '2024-02-20',
            'User_Name':username
                    }
        
        ces_data= {
            'CES_Identifier':'',
            'CDS_Identifier':'',
            'Concept_LLM_Summary':'Concept_Summary',
            'Reference_Text':'disease_reference',
            'Response_Attribute':'response_text',
            'User_Feedback':'',
            'Document_Page_Number': '',
            'Creation_Date': '2024-02-27',
            'Last_Updated_Dts': '2024-02-27',
            'User_Name': username
                    }
        
        db_object.posttocd(cd_data)
        # print("Data Posted to CD successfully")
        writeToLog("Data Posted to CD successfully")

        with open(os.path.join(prior_auth_locations, filename), 'r') as f: # open in readonly mode
                medical_record:dict=json.loads(f.read())
        # print(f"{filename} read successfully")
        writeToLog(f"{filename} read successfully")    
        # Get the prompts for the patient and provider details
                #This has a hard coded value, please correct
        FirstPageOfMedicalRecord:str = medical_record['2']
        Patient_Promp_Creator_Obj = promptcreator(PatientPromptPath,FirstPageOfMedicalRecord)
        Provider_Promp_Creator_Obj = promptcreator(ProviderPromptPath,FirstPageOfMedicalRecord)
        Patient_Prompt = Patient_Promp_Creator_Obj.promptbuilder()
        Provider_Prompt = Provider_Promp_Creator_Obj.promptbuilder()
            
            

        customllm=ExlAI()
        qna=QnA()
        program_object:program = program(responseModel,customllm)
        
        # Patient program to get the patient Details
        patientProgram:program = program(PatientModel,customllm)
        patientDetailsRespond = patientProgram.programrespond(Patient_Prompt)
        try:
            patientDetails:PatientModel = patientDetailsRespond()
            # print("Patient Details retrieved using LLM")
            writeToLog("Patient Details retrieved using LLM")
        except Exception as e:
            #  print(f"Could not retrieve patient Details from LLM cause of error {e}")
             writeToLog(f"Could not retrieve patient Details from LLM cause of error {e}")

        # Provider program to get the provider details
        providerProgram:program = program(ProviderModel,customllm)
        providerDetailsRespond = providerProgram.programrespond(Provider_Prompt)
        try:
            providerDetails:ProviderModel = providerDetailsRespond()
            # print("Provider Details retrieved using LLM")
            writeToLog("Provider Details retrieved using LLM")
        except Exception as e:
            #  print(f"Could not retrieve Provider Details from LLM cause of error {e}")
             writeToLog(f"Could not retrieve Provider Details from LLM cause of error {e}")
        
        
        patientDetailsDict:dict = {
            "Document_Identifier": document_id,
            "Patient_Id":document_id,
            "Patient_Name": patientDetails.Patient_Name,
            "Patient_Gender": patientDetails.Patient_Gender,
            "Patient_DoB": patientDetails.Patient_DoB.strftime('%d%b%Y'),
            "Patient_Address_line":patientDetails.Patient_Address_line,
            "Patient_State": patientDetails.Patient_State,
            "Patient_Contact": patientDetails.Patient_Contact_Number
            }
        print(patientDetailsDict)
       

        providerDetailsDict:dict = {
            "Document_Identifier": document_id,
            "Provider_Id": document_id,
            "Provider_Name": providerDetails.Provider_Name,
            "Provider_Address_line": providerDetails.Provider_Address_line,
            "Provider_State":providerDetails.Provider_State,
            "Provider_Contact":providerDetails.Provider_Contact
            }
        
        db_object.postToPatientdb(patientDetailsDict)
        # print("Posted Patient details to db")
        writeToLog("Posted Patient details to db")
        db_object.postToProviderdb(providerDetailsDict)
        # print("Posted Provider details to db")
        writeToLog("Posted Provider details to db")

        response_object:response= response(PromptPath=PromptPath, MedicalRecord=medical_record,program=program_object)
        concept_evidence:dict[str,dict] = response_object.generateResponse(concepts)
        # print("Response of the concept eviences generated by the LLM")
        writeToLog("Response of the concept eviences generated by the LLM")
        for conceptid in concept_evidence:
                cds_id = str(uuid.uuid4())
                writeToLog(f"cds id for the {conceptid}:{cds_id}")
                conceptevidences:str = ""
                cds_data['CDS_Identifier'] = cds_id
                ces_data['CDS_Identifier'] = cds_id
                
                cds_data['Concept_Name'] = concepts[conceptid]

                now = datetime.now()
                formatted_date = now.strftime('%Y-%m-%d %H:%M:%S')
                cds_data['Creation_Date'] = formatted_date
                cds_data['Last_Updated_Dts'] = formatted_date


                for page in concept_evidence[conceptid]:
                    now = datetime.now()
                    formatted_date = now.strftime('%Y-%m-%d %H:%M:%S')
                    
                    ces_data['Creation_Date'] = formatted_date
                    ces_data['Last_Updated_Dts'] = formatted_date
                    ces_data['CES_Identifier'] = str(uuid.uuid4())
                    writeToLog(f"ces id for the cds id {cds_id} at page {page}:{cds_id}")
                    ces_data['Reference_Text'] = concept_evidence[conceptid][page].reference_text
                    ces_data['Concept_LLM_Summary'] = concept_evidence[conceptid][page].generated_text
                    attributes = concept_evidence[conceptid][page].attributes
                    ces_data['Response_Attribute'] = str(attributes)
                    
                    ces_data['Document_Page_Number'] = str(page)
                    db_object.posttoces(ces_data)
                    # print(f"ces data updated for the concept {concept_evidence[conceptid]} at page {page}")
                    writeToLog(f"ces data updated for the concept {conceptid} at page {page}")

                    conceptevidences += "Evidence Text from LLM: "+(concept_evidence[conceptid][page].generated_text)
                    conceptevidences += " Reference Text from Medical Record: " + (concept_evidence[conceptid][page].reference_text)
                    conceptevidences += " Page Number of Medical Record: " + (page)
                    conceptevidences += "\n"

                Summarize_Concept_PromptCreator_Obj = promptcreator(conceptSummarizePromptPath,conceptevidences)
                Summarize_Concept_Prompt:str = Summarize_Concept_PromptCreator_Obj.promptbuilder()
                SummarizeConceptProgram:program = program(ConceptSummaryModel,customllm)
                SummarizeConceptRespond = SummarizeConceptProgram.programrespond(Summarize_Concept_Prompt)
                ConceptSummary:ConceptSummaryModel = SummarizeConceptRespond()
                
                
                cds_data['All_Evidence_Summary'] = ConceptSummary.AllEvidenceSummary

                db_object.posttocds(cds_data)
                # print("cds data posted to the db")
                writeToLog("cds data posted to the db")

        # Upload the file to the archive
        uploadToJsonArchive(os.path.join(prior_auth_locations, filename))
        # print("Json file uploaded to archive")
        writeToLog("Json file uploaded to archive")
        # Delete the file from local
        # os.remove(os.path.join(prior_auth_locations, filename))

        #Delete the file from blob
        # deleteFromJsonSource(os.path.join(prior_auth_locations, filename))

                    
            
        


