import requests
import os
import json
from datetime import datetime
from functions import *
import uuid

def getNewId():
    result = uuid.uuid4()
    return result.hex

#filename ='C:\\Users\\rishabh98551\\OneDrive - EXLService.com (I) Pvt. Ltd\\Desktop\\Parser\\synthea_sample_data_fhir_latest\\CaregapsAuthorAndReporter.json'
#with open(filename, "r",encoding='utf-8') as read_it:
#        data = json.load(read_it)

document_id = getNewId()
#document_id = 'dfa3e552c3df4165979dd813f2e08052'
print(document_id)
now = datetime.now()
formatted_date = now.strftime('%Y-%m-%d %H:%M:%S')

CD_data = {
'Document_Name': 'Prior_Auth_Request_Actemera12mg_v2.pdf',
'Document_Path':'C:\\Aetna\\PA_Folder\\Prior_Auth_Request_Actemera12mg_v2.pdf',
'Document_Review_Status':'Not-Started',
'Prior_Auth_Description':'Actemera - 12mg/ml',
}    
CD_data['Document_Evaluation_dts'] =formatted_date
CD_data['Document_Receive_dts'] = formatted_date
CD_data['Identifier'] = document_id
CD_data['Patient_Document_id']  = document_id
CD_data['Provider_Document_id'] = document_id
CD_data['User_Name'] = 'Rishabh'

url = ' http://127.0.0.1:5000/cd'
headers = {'Accept-Charset': 'utf-8','Accept':'application/json',"accept-encoding" : "gzip",'Content-Type':'application/fhir+json'}
data1 =json.dumps(CD_data)
response = requests.post(url, data=data1, headers=headers)
#response = requests.put(url, data=data1, headers=headers)
print(response.text)


PAT_data= {
    'Document_Identifier':'clinical_id4312',
    'Patient_Id':'pat_id3111',
    'Patient_Name':'Betty890 Cameron381',
    'Patient_Gender':'Female',
    'Patient_DoB':'04Dec1959',
    'Patient_Address_line':'937 Lakin Fort, Boston',
    'Patient_State':'MA',
    'Patient_Contact':'' 
}
PAT_data['Document_Identifier'] = document_id


url = ' http://127.0.0.1:5000/pat'
headers = {'Accept-Charset': 'utf-8','Accept':'application/json',"accept-encoding" : "gzip",'Content-Type':'application/fhir+json'}
data1 =json.dumps(PAT_data)
response = requests.post(url, data=data1, headers=headers)
print(response.text)
PRO_data= {
    'Document_Identifier':'clinical_id4330',
    'Provider_Id':'pat_id3211',
    'Provider_Name':'MASSACHUSETTS GENERAL PHYSICIANS ORGANIZATION, INC',
    'Provider_Address_line':'151 EVERETT AVE CHELSEA',
    'Provider_State':'',
    'Provider_Contact':'' 
}
PRO_data['Document_Identifier'] = document_id

url = ' http://127.0.0.1:5000/pro'
headers = {'Accept-Charset': 'utf-8','Accept':'application/json',"accept-encoding" : "gzip",'Content-Type':'application/fhir+json'}
data1 =json.dumps(PRO_data)
response = requests.post(url, data=data1, headers=headers)

CDS_data={
            "All_Evidence_Feedback": '0',
            "All_Evidence_Summary": "The patient is experiencing tenderness and pain in small joints of fingers and toes. He Complains pain in a larger joint - knee and shoulder.",
            "CDS_Identifier": "35bf4898f6e84fe8a515ca53e73b2e3b",
            "Concept_Name": "ICD Codes",
            "Concept_Review_Status": "Not-Started",
            "Creation_Date": "Mon, 26 Feb 2024 17:32:42 GMT",
            "Identifier": "dfa3e552c3df4165979dd813f2e08052",
            "Last_Updated_Dts": "Mon, 26 Feb 2024 17:32:42 GMT",
            "User_Name": "Rishab",
            "User_Notes": ""
        }
 
CDS_data['Last_Updated_Dts']=formatted_date
CDS_data['Creation_Date'] =formatted_date
CDS_id = getNewId()
CDS_data['CDS_Identifier'] = CDS_id
CDS_data['Identifier'] = document_id

#print(CDS_data)
url = ' http://127.0.0.1:5000/cds'
headers = {'Accept-Charset': 'utf-8','Accept':'application/json',"accept-encoding" : "gzip",'Content-Type':'application/fhir+json'}
data1 =json.dumps(CDS_data)
response = requests.post(url, data=data1, headers=headers)
print(response.text)

CES_data = {
            "CDS_Identifier": "35bf4898f6e84fe8a515ca53e73b2e3b",
            "CES_Identifier": "0607e12fe30b42de886df82cb8fc4eec",
            "Concept_LLM_Summary": "This is the list of all ICD Codes present in patient's Medical History",
            "Creation_Date": "Mon, 26 Feb 2024 17:32:42 GMT",
            "Document_Page_Number": "6",
            "Last_Updated_Dts": "Mon, 26 Feb 2024 17:32:42 GMT",
            "Reference_Text": "K51.019",
            "Response_Attribute": "{'condition': 'K51.019(Ulcerative Pancolitis) diagnosed on 2019-01-27'}",
            "User_Feedback": "1",
            "User_Name": "Rishabh"
        }

CES_data['Last_Updated_Dts']=formatted_date
CES_data['Creation_Date'] =formatted_date
CES_data['CDS_Identifier'] =CDS_id
CES_data['CES_Identifier'] =getNewId()
#CES_data['Identifier'] = document_id
#print(CES_data)
url = ' http://127.0.0.1:5000/ces'
headers = {'Accept-Charset': 'utf-8','Accept':'application/json',"accept-encoding" : "gzip",'Content-Type':'application/fhir+json'}
data1 =json.dumps(CES_data)
response = requests.post(url, data=data1, headers=headers)

CES_data = {
            "CDS_Identifier": "35bf4898f6e84fe8a515ca53e73b2e3b",
            "CES_Identifier": "0607e12fe30b42de886df82cb8fc4eec",
            "Concept_LLM_Summary": "This is the list of all ICD Codes present in patient's Medical History",
            "Creation_Date": "Mon, 26 Feb 2024 17:32:42 GMT",
            "Document_Page_Number": "6",
            "Last_Updated_Dts": "Mon, 26 Feb 2024 17:32:42 GMT",
            "Reference_Text": "R70.0",
            "Response_Attribute": "{'condition': 'R70.0(Elevated ESR) diagnosed on 2019-02-05'}",
            "User_Feedback": "1",
            "User_Name": "Rishabh"
        }

CES_data['Last_Updated_Dts']=formatted_date
CES_data['Creation_Date'] =formatted_date
CES_data['CDS_Identifier'] =CDS_id
CES_data['CES_Identifier'] =getNewId()
#CES_data['Identifier'] = document_id
#print(CES_data)
url = ' http://127.0.0.1:5000/ces'
headers = {'Accept-Charset': 'utf-8','Accept':'application/json',"accept-encoding" : "gzip",'Content-Type':'application/fhir+json'}
data1 =json.dumps(CES_data)
response = requests.post(url, data=data1, headers=headers)


CES_data = {
            "CDS_Identifier": "35bf4898f6e84fe8a515ca53e73b2e3b",
            "CES_Identifier": "0607e12fe30b42de886df82cb8fc4eec",
            "Concept_LLM_Summary": "This is the list of all ICD Codes present in patient's Medical History",
            "Creation_Date": "Mon, 26 Feb 2024 17:32:42 GMT",
            "Document_Page_Number": "7",
            "Last_Updated_Dts": "Mon, 26 Feb 2024 17:32:42 GMT",
            "Reference_Text": "R70.0",
            "Response_Attribute": "{'condition': 'E118(Diabetes) diagnosed on 2019-02-12'}",
            "User_Feedback": "1",
            "User_Name": "Rishabh"
        }

CES_data['Last_Updated_Dts']=formatted_date
CES_data['Creation_Date'] =formatted_date
CES_data['CDS_Identifier'] =CDS_id
CES_data['CES_Identifier'] =getNewId()
#CES_data['Identifier'] = document_id
#print(CES_data)
url = ' http://127.0.0.1:5000/ces'
headers = {'Accept-Charset': 'utf-8','Accept':'application/json',"accept-encoding" : "gzip",'Content-Type':'application/fhir+json'}
data1 =json.dumps(CES_data)
response = requests.post(url, data=data1, headers=headers)

CES_data = {
            "CDS_Identifier": "35bf4898f6e84fe8a515ca53e73b2e3b",
            "CES_Identifier": "0607e12fe30b42de886df82cb8fc4eec",
            "Concept_LLM_Summary": "This is the list of all ICD Codes present in patient's Medical History",
            "Creation_Date": "Mon, 26 Feb 2024 17:32:42 GMT",
            "Document_Page_Number": "7",
            "Last_Updated_Dts": "Mon, 26 Feb 2024 17:32:42 GMT",
            "Reference_Text": "M06.9",
            "Response_Attribute": "[{'condition': 'E78.1(Hypertriglyceridemia (disorder)) diagnosed on 1991-02-15'},{'condition': 'E88.810(Metabolic syndrome X (disorder)) diagnosed on 2017-02-18'},{'condition': 'I82.4(DVT) diagnosed on 2019-02-18'},{'condition': 'M06.9(Rheumatoid Arthritis) diagnosed on 2019-02-21'},{'condition': 'I82.4(DVT) diagnosed on 2019-02-18'}     ]",
            "User_Feedback": "1",
            "User_Name": "Rishabh"
        }

CES_data['Last_Updated_Dts']=formatted_date
CES_data['Creation_Date'] =formatted_date
CES_data['CDS_Identifier'] =CDS_id
CES_data['CES_Identifier'] =getNewId()
#CES_data['Identifier'] = document_id
#print(CES_data)
url = ' http://127.0.0.1:5000/ces'
headers = {'Accept-Charset': 'utf-8','Accept':'application/json',"accept-encoding" : "gzip",'Content-Type':'application/fhir+json'}
data1 =json.dumps(CES_data)
response = requests.post(url, data=data1, headers=headers)

CDS_data={
            "All_Evidence_Feedback": '0',
            "All_Evidence_Summary": "The patient is diagnosed with Ulcerative Pancolitis",
            "CDS_Identifier": "35bf4898f6e84fe8a515ca53e73b2e3b",
            "Concept_Name": "Ulcerative collitis",
            "Concept_Review_Status": "Not-Started",
            "Creation_Date": "Mon, 26 Feb 2024 17:32:42 GMT",
            "Identifier": "dfa3e552c3df4165979dd813f2e08052",
            "Last_Updated_Dts": "Mon, 26 Feb 2024 17:32:42 GMT",
            "User_Name": "Rishab",
            "User_Notes": ""
        }
 
CDS_data['Last_Updated_Dts']=formatted_date
CDS_data['Creation_Date'] =formatted_date
CDS_id = getNewId()
CDS_data['CDS_Identifier'] = CDS_id
CDS_data['Identifier'] = document_id

#print(CDS_data)
url = ' http://127.0.0.1:5000/cds'
headers = {'Accept-Charset': 'utf-8','Accept':'application/json',"accept-encoding" : "gzip",'Content-Type':'application/fhir+json'}
data1 =json.dumps(CDS_data)
response = requests.post(url, data=data1, headers=headers)
print(response.text)

CES_data = {
            "CDS_Identifier": "35bf4898f6e84fe8a515ca53e73b2e3b",
            "CES_Identifier": "0607e12fe30b42de886df82cb8fc4eec",
            "Concept_LLM_Summary": "Found the evidences of patient having Ulcerative Pancolitis",
            "Creation_Date": "Mon, 26 Feb 2024 17:32:42 GMT",
            "Document_Page_Number": "6",
            "Last_Updated_Dts": "Mon, 26 Feb 2024 17:32:42 GMT",
            "Reference_Text": "K51.019",
            "Response_Attribute": "{'condition': 'K51.019(Ulcerative Pancolitis) diagnosed on 2019-01-27'}",
            "User_Feedback": "1",
            "User_Name": "Rishabh"
        }

CES_data['Last_Updated_Dts']=formatted_date
CES_data['Creation_Date'] =formatted_date
CES_data['CDS_Identifier'] =CDS_id
CES_data['CES_Identifier'] =getNewId()
#CES_data['Identifier'] = document_id
#print(CES_data)
url = ' http://127.0.0.1:5000/ces'
headers = {'Accept-Charset': 'utf-8','Accept':'application/json',"accept-encoding" : "gzip",'Content-Type':'application/fhir+json'}
data1 =json.dumps(CES_data)
response = requests.post(url, data=data1, headers=headers)

CDS_data={
            "All_Evidence_Feedback": '0',
            "All_Evidence_Summary": "No Evidences of Cardiac Diseases Found",
            "CDS_Identifier": "35bf4898f6e84fe8a515ca53e73b2e3b",
            "Concept_Name": "Cardiac Disease",
            "Concept_Review_Status": "Not-Started",
            "Creation_Date": "Mon, 26 Feb 2024 17:32:42 GMT",
            "Identifier": "dfa3e552c3df4165979dd813f2e08052",
            "Last_Updated_Dts": "Mon, 26 Feb 2024 17:32:42 GMT",
            "User_Name": "Rishab",
            "User_Notes": ""
        }
 
CDS_data['Last_Updated_Dts']=formatted_date
CDS_data['Creation_Date'] =formatted_date
CDS_id = getNewId()
CDS_data['CDS_Identifier'] = CDS_id
CDS_data['Identifier'] = document_id

#print(CDS_data)
url = ' http://127.0.0.1:5000/cds'
headers = {'Accept-Charset': 'utf-8','Accept':'application/json',"accept-encoding" : "gzip",'Content-Type':'application/fhir+json'}
data1 =json.dumps(CDS_data)
response = requests.post(url, data=data1, headers=headers)
print(response.text)

CES_data = {
            "CDS_Identifier": "35bf4898f6e84fe8a515ca53e73b2e3b",
            "CES_Identifier": "0607e12fe30b42de886df82cb8fc4eec",
            "Concept_LLM_Summary": "No evidence of cardiac disease found",
            "Creation_Date": "Mon, 26 Feb 2024 17:32:42 GMT",
            "Document_Page_Number": "",
            "Last_Updated_Dts": "Mon, 26 Feb 2024 17:32:42 GMT",
            "Reference_Text": "",
            "Response_Attribute": "",
            "User_Feedback": "1",
            "User_Name": "Rishabh"
        }

CES_data['Last_Updated_Dts']=formatted_date
CES_data['Creation_Date'] =formatted_date
CES_data['CDS_Identifier'] =CDS_id
CES_data['CES_Identifier'] =getNewId()
#CES_data['Identifier'] = document_id
#print(CES_data)
url = ' http://127.0.0.1:5000/ces'
headers = {'Accept-Charset': 'utf-8','Accept':'application/json',"accept-encoding" : "gzip",'Content-Type':'application/fhir+json'}
data1 =json.dumps(CES_data)
response = requests.post(url, data=data1, headers=headers)

CDS_data={
            "All_Evidence_Feedback": '0',
            "All_Evidence_Summary": "Pain worsens in Knee",
            "CDS_Identifier": "35bf4898f6e84fe8a515ca53e73b2e3b",
            "Concept_Name": "Disease Progression",
            "Concept_Review_Status": "Not-Started",
            "Creation_Date": "Mon, 26 Feb 2024 17:32:42 GMT",
            "Identifier": "dfa3e552c3df4165979dd813f2e08052",
            "Last_Updated_Dts": "Mon, 26 Feb 2024 17:32:42 GMT",
            "User_Name": "Rishab",
            "User_Notes": ""
        }
 
CDS_data['Last_Updated_Dts']=formatted_date
CDS_data['Creation_Date'] =formatted_date
CDS_id = getNewId()
CDS_data['CDS_Identifier'] = CDS_id
CDS_data['Identifier'] = document_id

#print(CDS_data)
url = ' http://127.0.0.1:5000/cds'
headers = {'Accept-Charset': 'utf-8','Accept':'application/json',"accept-encoding" : "gzip",'Content-Type':'application/fhir+json'}
data1 =json.dumps(CDS_data)
response = requests.post(url, data=data1, headers=headers)
print(response.text)

CES_data = {
            "CDS_Identifier": "35bf4898f6e84fe8a515ca53e73b2e3b",
            "CES_Identifier": "0607e12fe30b42de886df82cb8fc4eec",
            "Concept_LLM_Summary": "Knee pain - relapsing",
            "Creation_Date": "Mon, 26 Feb 2024 17:32:42 GMT",
            "Document_Page_Number": "61",
            "Last_Updated_Dts": "Mon, 26 Feb 2024 17:32:42 GMT",
            "Reference_Text": "worsening pain in the knee",
            "Response_Attribute": "{'Complaints': 'Knee pain - relapsing'}",
            "User_Feedback": "1",
            "User_Name": "Rishabh"
        }

CES_data['Last_Updated_Dts']=formatted_date
CES_data['Creation_Date'] =formatted_date
CES_data['CDS_Identifier'] =CDS_id
CES_data['CES_Identifier'] =getNewId()
#CES_data['Identifier'] = document_id
#print(CES_data)
url = ' http://127.0.0.1:5000/ces'
headers = {'Accept-Charset': 'utf-8','Accept':'application/json',"accept-encoding" : "gzip",'Content-Type':'application/fhir+json'}
data1 =json.dumps(CES_data)
response = requests.post(url, data=data1, headers=headers)

CDS_data={
            "All_Evidence_Feedback": '0',
            "All_Evidence_Summary": "Medication History of Patient",
            "CDS_Identifier": "35bf4898f6e84fe8a515ca53e73b2e3b",
            "Concept_Name": "Medication",
            "Concept_Review_Status": "Not-Started",
            "Creation_Date": "Mon, 26 Feb 2024 17:32:42 GMT",
            "Identifier": "dfa3e552c3df4165979dd813f2e08052",
            "Last_Updated_Dts": "Mon, 26 Feb 2024 17:32:42 GMT",
            "User_Name": "Rishab",
            "User_Notes": ""
        }
 
CDS_data['Last_Updated_Dts']=formatted_date
CDS_data['Creation_Date'] =formatted_date
CDS_id = getNewId()
CDS_data['CDS_Identifier'] = CDS_id
CDS_data['Identifier'] = document_id

#print(CDS_data)
url = ' http://127.0.0.1:5000/cds'
headers = {'Accept-Charset': 'utf-8','Accept':'application/json',"accept-encoding" : "gzip",'Content-Type':'application/fhir+json'}
data1 =json.dumps(CDS_data)
response = requests.post(url, data=data1, headers=headers)
print(response.text)

CES_data = {
            "CDS_Identifier": "35bf4898f6e84fe8a515ca53e73b2e3b",
            "CES_Identifier": "0607e12fe30b42de886df82cb8fc4eec",
            "Concept_LLM_Summary": "Patient's Current Medications",
            "Creation_Date": "Mon, 26 Feb 2024 17:32:42 GMT",
            "Document_Page_Number": "3",
            "Last_Updated_Dts": "Mon, 26 Feb 2024 17:32:42 GMT",
            "Reference_Text": "RxNorm 316049",
            "Response_Attribute": "[{'medication': 'RxNorm 316049(Hydrochlorothiazide 25 MG) prescribed on 2019-05-27'}, {'medication': 'RxNorm 860975(24 HR Metformin hydrochloride 500 MG Extended Release Oral Tablet) prescribed on 2019-06-12'},{'medication': 'RxNorm 1655959(Methotrexate 250 MG in 10 ML Inj) prescribed on 2019-07-27'}]",
            "User_Feedback": "1",
            "User_Name": "Rishabh"
        }

CES_data['Last_Updated_Dts']=formatted_date
CES_data['Creation_Date'] =formatted_date
CES_data['CDS_Identifier'] =CDS_id
CES_data['CES_Identifier'] =getNewId()
#CES_data['Identifier'] = document_id
#print(CES_data)
url = ' http://127.0.0.1:5000/ces'
headers = {'Accept-Charset': 'utf-8','Accept':'application/json',"accept-encoding" : "gzip",'Content-Type':'application/fhir+json'}
data1 =json.dumps(CES_data)
response = requests.post(url, data=data1, headers=headers)

#print(response.text)
#url = ' http://127.0.0.1:5000/request'
#url = ' http://127.0.0.1:5000/cd/1a4b3047a105451cbe146df738d2081'
#url = ' http://127.0.0.1:5000/cds'
#headers = {'Accept-Charset': 'utf-8','Accept':'application/json',"accept-encoding" : "gzip",'Content-Type':'application/fhir+json'}
#data1 =json.dumps(data)
#response = requests.post(url, data=data1, headers=headers)
#print(response.text)


#response = requests.get(url, headers=headers)
#print(response.text)


#response = requests.delete(url, headers=headers)
#print(response.text)

#response = requests.put(url, data=data1, headers=headers)
#print(response.text)
'''
# CD_data = {
# 'Document_Name': 'Actemera.pdf',
# 'Document_Path':'/test/test1/Actemera.pdf',
# 'Document_Review_Status':'Not-Started',
# 'Prior_Auth_Description':'Actemera - 12ml',
# }    
# CD_data['Document_Evaluation_dts'] =formatted_date
# CD_data['Document_Receive_dts'] = formatted_date
# CD_data['Identifier'] = document_id
# CD_data['Patient_Document_id']  = document_id
# CD_data['Provider_Document_id'] = document_id
# CD_data['User_Name'] = 'Rishabh'

# url = ' http://127.0.0.1:5000/cd'
# headers = {'Accept-Charset': 'utf-8','Accept':'application/json',"accept-encoding" : "gzip",'Content-Type':'application/fhir+json'}
# data1 =json.dumps(CD_data)
# #response = requests.post(url, data=data1, headers=headers)
# #response = requests.put(url, data=data1, headers=headers)
# #print(response.text)

# CDS_data= {'CDS_Identifier': 'bf5cdc4491ce45c5bba8d8b3f3062d05',  
#        'Concept_Name': 'Heart-Cardiac Condition', 
#        'User_Notes': 'Note_Updated', 
#        'Concept_Review_Status': 'In-Progress',   
#        'Last_Updated_dts': '', 
#        'User_Name': 'Rishabh'}
# CDS_data['Last_Updated_Dts']=formatted_date
# CDS_data['Creation_Date'] =formatted_date
# CDS_ID = getNewId()
# CDS_data['CDS_Identifier'] =CDS_ID
# CDS_data['User_Name'] ='Upd_Rishab' 
# CDS_data['Identifier'] = document_id
# print(CDS_data)
# url = ' http://127.0.0.1:5000/cds'
# headers = {'Accept-Charset': 'utf-8','Accept':'application/json',"accept-encoding" : "gzip",'Content-Type':'application/fhir+json'}
# data1 =json.dumps(CDS_data)
# response = requests.post(url, data=data1, headers=headers)
# #response = requests.put(url, data=data1, headers=headers)

# print(response.text)

CES_data= {
        "CDS_Identifier": "35bf4898f6e84fe8a515ca53e73b",
        "CES_Identifier": "0607e12fe30b42de886df82cb8fc4zzz",
        "Concept_LLM_Summary": "Concept_Summary123",
        "Creation_Date": "2023-03-01",
        "Document_Page_Number": "21",
        "Last_Updated_Dts": "2023-03-01",
        "Reference_Text": "disease_reference123",
        "Response_Attribute": "response_text123",
        "User_Feedback": "1",
        "User_Name": "sk2"
       }
CES_data['Last_Updated_Dts']=formatted_date
CES_data['Creation_Date'] =formatted_date
#CES_data['CDS_Identifier'] =CDS_ID
#CES_data['CES_Identifier'] =getNewId()
#CES_data['Identifier'] = document_id
print(CES_data)



cds_data = {
        "CDS_Identifier": "35bf4898f6e84fe8a515ca53e73b",
        "Concept_Name" : "Heart-Cardiac Condition2",
        "All_Evidence_Summary" : "Test",
        "All_Evidence_Feedback": "0",
        "Concept_Review_Status" : "Complete",
        "Creation_Date" : "Mon, 26 Feb 2024 17:32:42 GMT",
        "Identifier" : "cd_id4800",
        "Last_Updated_Dts" : "2024-03-05",
        "User_Name" : "sk5",
        "User_Notes" : "Note_Updated224"
       }

CD_data = {
  'Document_Name': 'Prior_Authorization_Request_Actemera.pdf',
  'Document_Path':'Actemera.pdf',
  'Document_Review_Status':'Not-Started',
  'Prior_Auth_Description':'Actemera - 12ml',
}    
CD_data['Document_Evaluation_dts'] =formatted_date
CD_data['Document_Receive_dts'] = formatted_date
CD_data['Identifier'] = '63c5e211-bb37-4f2d-8712-068406b8b531'
CD_data['Patient_Document_id']  = '63c5e211-bb37-4f2d-8712-068406b8b531'
CD_data['Provider_Document_id'] = document_id
CD_data['User_Name'] = 'Rishabh'

url = 'http://127.0.0.1:5000/cd/63c5e211-bb37-4f2d-8712-068406b8b531'
headers = {'Accept-Charset': 'utf-8','Accept':'application/json',"accept-encoding" : "gzip",'Content-Type':'application/fhir+json'}
data1 =json.dumps(cds_data)
response = requests.put(url, data=data1, headers=headers)
#response = requests.put(url, data=data1, headers=headers)
print(response.text)
'''